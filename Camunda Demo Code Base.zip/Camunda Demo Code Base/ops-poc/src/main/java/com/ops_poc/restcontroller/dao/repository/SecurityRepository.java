package com.ops_poc.restcontroller.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ops_poc.restcontroller.dao.model.*;

import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;



@Repository
public interface SecurityRepository extends CrudRepository<SecurityDetails, Long> {
	
	 @Query(value = "SELECT nextval('HIBERNATE_SEQUENCE') ", nativeQuery = 
		        true)
		 Long getApplicationID();
	 
	 SecurityDetails findByOpsApplicationID(long opsID);
	 
	 
	 
	 @Transactional
	 @Modifying
	 @Query("UPDATE SecurityDetails sd SET sd.taskID = :taskID WHERE sd.opsApplicationID = :opsApplicationID")
	 int updateTaskID(@Param("opsApplicationID") long opsApplicationID, @Param("taskID") String taskID);
	 
	 SecurityDetails findBytaskID(String title);
	 

	
	 
	 
}
