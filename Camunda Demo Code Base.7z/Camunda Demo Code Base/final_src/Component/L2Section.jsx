import React, { Component, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Box from "@material-ui/core/Box";
import GuarantorType from "./GuarantorType";
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";

import FormLabel from "@material-ui/core/FormLabel";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%"
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "left",
    color: theme.palette.text.secondary
  }
}));

export default function L2Section() {
  const classes = useStyles();
  const [value, setValue] = React.useState("female");
  const { L2Information, setL2Information } = useContext(
    CreateSecurityRequestContext
  );

  const L2InformationLocal = { ...L2Information };

  const handleChangeL2Comments = event => {
    L2InformationLocal.L2Comments = event.target.value;
    setL2Information(L2InformationLocal);
  };

  const handleChangeL2Action = event => {
    L2InformationLocal.L2Action = event.target.value;
    setL2Information(L2InformationLocal);
  };

  return (
    <div className={classes.root}>
      <ExpansionPanel>
        <ExpansionPanelSummary
          expandIcon={<ExpandMoreIcon />}
          style={{ backgroundColor: "#2196f3" }}
          aria-controls="paneL2a-content"
          id="paneL2a-header"
        >
          <Typography className={classes.heading}>L2 Information</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Grid container spacing={1}>
            <Grid container item xs={12} spacing={2}>
              {/* <Grid item xs={12}>
                <Paper className={classes.paper}>
                  <div style={{ width: "100%" }}>
                    <FormControl component="fieldset">
                      <FormLabel component="legend">
                        Are there any closure that are relevent to the
                        application ?
                      </FormLabel>
                      <RadioGroup
                        row
                        aria-label="gender"
                        name="gender1"
                        value={"England (or) Wales"}
                      >
                        <FormControlLabel
                          value="Yes"
                          control={<Radio />}
                          label="Yes"
                        />
                        <FormControlLabel
                          value="No"
                          control={<Radio />}
                          label="No"
                        />
                      </RadioGroup>
                    </FormControl>
                  </div>
                </Paper>
              </Grid> */}

              <Grid item xs={12}>
                <FormControl
                  margin="normal"
                  fullWidth
                  //style={{ display: searchType.cin }}
                >
                  <InputLabel htmlFor="name">L2 Comments</InputLabel>
                  <Input
                    id="name"
                    type="text"
                    multiline
                    onChange={handleChangeL2Comments}
                    value={L2InformationLocal.L2Comments}
                  />
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <FormControl
                  className={classes.formControl}
                  style={{ minWidth: 500 }}
                >
                  <InputLabel id="demo-simple-select-label">
                    L2 Action ?
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    // value={GuaratorType.type}
                    native
                    onChange={handleChangeL2Action}
                    //value={securityDetailsLocal.numberOfSecurity}
                    defaultValue={L2InformationLocal.L2Action}
                  >
                    <option value={"Please Select"}>Please Select</option>
                    <option value={"Approved"}>Approved</option>
                    <option value={"Reject"}>Reject</option>
                    <option value={"L1 Rework"}>L1 Rework</option>
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </Grid>
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
  );
}
