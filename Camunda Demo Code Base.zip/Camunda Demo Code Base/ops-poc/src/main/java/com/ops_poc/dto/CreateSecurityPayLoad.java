package com.ops_poc.dto;

import org.springframework.beans.factory.annotation.Autowired;

import com.ops_poc.restcontroller.dao.model.*;

public class CreateSecurityPayLoad {
	
    @Autowired
	private CreateSecurityRequest createSecurityRequest;
    
    @Autowired
	private SecurityDetailsResponse securityDetailsResponse;
	               
	
    public CreateSecurityPayLoad() {
		super();
	
	}
    
	
	public SecurityDetailsResponse getSecurityDetailsResponse() {
		return securityDetailsResponse;
	}

	public void setSecurityDetailsResponse(SecurityDetailsResponse securityDetailsResponse) {
		this.securityDetailsResponse = securityDetailsResponse;
	}

	

	public CreateSecurityRequest getCreateSecurityRequest() {
		return createSecurityRequest;
	}



	public void setCreateSecurityRequest(CreateSecurityRequest createSecurityReq) {
		this.createSecurityRequest = createSecurityReq;
	}


	
}
