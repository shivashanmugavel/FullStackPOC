import React, { Component, useContext, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import Menu from "@material-ui/core/Menu";
import PowerSettingsNewIcon from "@material-ui/icons/PowerSettingsNew";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import { useHistory } from "react-router-dom";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";
//import "bootstrap/dist/css/bootstrap.css";

const Navbar = props => {
  const StyledMenu = withStyles({
    paper: {
      border: "1px solid #d3d4d5"
    }
  })(props => (
    <Menu
      elevation={0}
      getContentAnchorEl={null}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center"
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "center"
      }}
      {...props}
    />
  ));

  const { loggedInDetails, setloggedInDetails } = useContext(
    CreateSecurityRequestContext
  );

  const localLoggedInDetails = { ...loggedInDetails };

  console.log("props detaisl props  " + JSON.stringify(props));
  let history = useHistory();

  const signoutUserBtn = () => {
    localLoggedInDetails.isLogged = "false";
    localLoggedInDetails.userID = "";
    setloggedInDetails(localLoggedInDetails);
    history.push("/Signout");
  };

  return (
    /* this route will reload a entire page -- this is not a good design
    <div>
      <a> God's Fun time</a>
      <ul>
        <li>
          <a href="/">Homee</a>
        </li>
        <li>
          <a href="/About us">About US</a>
        </li>
        <li>
          <a href="/Contact US">Contact Us</a>
        </li>
      </ul>
    </div>
    */

    // alternate solution for above problem

    <nav class="navbar navbar-expand-sm bg-primary navbar-primary">
      <div class="navbar-nav">
        <div class="dropdown" style={{ display: "" }}>
          <button
            type="button"
            class="btn btn-primary dropdown-toggle"
            data-toggle="dropdown"
          >
            Menu
          </button>

          <div class="dropdown-menu">
            <div class="d-flex MenuWidth">
              <section>
                <ul>
                  <a>
                    <Link to="/Create Security">Create Security </Link>
                  </a>
                  <li>
                    <Link to="/About us" class="dropdown-menu">
                      My Inbox
                    </Link>
                  </li>
                  <li>
                    <Link to="/MyTeamInbox">My Team Inbox</Link>
                  </li>
                  <li>
                    <Link to="/MyInbox">My Inbox</Link>
                  </li>
                  <li>
                    <div class="d-inline-flex">
                      <Link to="/Contact US">Security dashboard</Link>
                    </div>
                  </li>
                </ul>
              </section>
            </div>
          </div>
        </div>
      </div>
      <div class="float-right">
        <IconButton
          color="secondary"
          aria-label="add to shopping cart"
          style={{ marginLeft: "1200px" }}
          onClick={signoutUserBtn}
          fontSize="large"
        >
          <Tooltip title="Signout" arrow>
            <PowerSettingsNewIcon />
          </Tooltip>
        </IconButton>
        <div style={{ marginLeft: "1100px", width: "500px" }}>
          Welcome {props.userDetails} !
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
