package com.ops_poc.restcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.ops_poc.dto.CreateSecurityPayLoad;
import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;
import com.ops_poc.restcontroller.dao.repository.CustomerInformation;
import com.ops_poc.restcontroller.dao.repository.SecurityRepository;

@RestController
@RequestMapping(value = "/ops/GenericService")
public class OpsGenericServiceController {
	
	@Autowired
	private CustomerInformation customerRepository;
	@Autowired
	private Gson gson;
	private Iterable<CustomerDetails> cusDetails;
	
	@Autowired
	private SecurityRepository secRepo;
	
	@Autowired
	private OpsHealperClass ohc;
	
	
	
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/GetCustomerDetailsByCin")
	@PostMapping(
	        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}
	)
    public String getCustomerDetails(@RequestBody CustomerDetails custDetails)
	{
		
		 
		 cusDetails = customerRepository.getCustomerInformation(custDetails.getCustomerCin());
		//return customerRepository.findById((long) 1234567890);
		 return gson.toJson(cusDetails);
	}

	@RequestMapping("/AddCustomerDetailsByCin")
    public String  addCustomerDetailsDetails()
	{
		
		CustomerDetails cd1 = new CustomerDetails(1, "Ganesha", "1234567890", "eg@gmail.com","094444946185", "India", "gannesh" ,"ganesh" ,"Mr.Ganesh","Idayam");
		CustomerDetails cd2 = new CustomerDetails(2, "Muruga", "1234567891", "eg@gmail.com","094444946185", "India", "gannesh" ,"ganesh" ,"Mr.Ganesh","Idayam");
		CustomerDetails cd3 = new CustomerDetails(3, "Ganesha", "1234567892", "eg@gmail.com","094444946185", "India", "gannesh" ,"ganesh" ,"Mr.Ganesh","Idayam");
		CustomerDetails cd4 = new CustomerDetails(4, "ABC cottons", "123", "eg@gmail.com","094444946185", "India", "ABC pvt Ltd" ,"partnership" ,"Mr.Carol Sterlings","385 , church street -London ");
		CustomerDetails cd5 = new CustomerDetails(5, "McKinsey & Company", "55555", "MKC@gmail.com","094444946185", "United States Of America", "McKinsey & Co" ,"private" ,"James O. McKinsey","The Post Building" + 
				"100 Museum Street" + 
				"London" + 
				"WC1A 1PB" + 
				"United Kingdom");
		CustomerDetails cd6 = new CustomerDetails(6, "Boston Consulting Group", "666666", "BCG@gmail.com","0944448597", "United States", "Boston Groups" ,"partnership" ,"Mr.Bruce Henderson","Gustav Mahlerlaan 40 " + 
				"1082 MC Amsterdam " + 
				"P.O. Box 87597 " + 
				"Amsterdam 1080 JN" + 
				"Netherlands" + 
				"+31 20 548 4000 ");
		CustomerDetails cd7 = new CustomerDetails(7, "Xiaomi Corporation", "4444", "Xiommi@gmail.com","09484946185", "China", "Xiaomi Corporation" ,"Pubic" ,"Mr.Lei Jun","385 , China");
		
		customerRepository.save(cd1);
		customerRepository.save(cd2);
		customerRepository.save(cd3);
		customerRepository.save(cd4);
		customerRepository.save(cd5);
		customerRepository.save(cd6);
		customerRepository.save(cd7);
		
		cusDetails = customerRepository.findAll();
		
		
		return   gson.toJson(cusDetails);
		//return customerRepository.findById((long) 1234567890);
		
	}
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/getApplicationId")
    public String  getApplicationID()
	{
		
		
		System.out.println("controller repo info"+secRepo);
		
		System.out.println("controller repo info ohc"+ohc);
		long applicationID = secRepo.getApplicationID();
		
		
		return   gson.toJson(applicationID);
	
		
	}
	
	

}
