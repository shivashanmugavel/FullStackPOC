import React, { Component, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Box from "@material-ui/core/Box";
import PartnershipDetails from "./PartnershipDetails";

import FormLabel from "@material-ui/core/FormLabel";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput,
  MenuList
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%"
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "left",
    color: theme.palette.text.secondary
  }
}));

export default function GuarantorType() {
  const classes = useStyles();
  const [value, setValue] = React.useState("female");
  const { guarantorDetails, setGuarDetails } = useContext(
    CreateSecurityRequestContext
  );

  const gurDetails = { ...guarantorDetails };

  const [GuaratorType, setGuaratorType] = React.useState({
    type: gurDetails.guarantorType,
    isPartnership:
      gurDetails.guarantorType == "Partership" ||
      gurDetails.guarantorType == "Scotish Firm"
        ? ""
        : "none"
  });

  const handleGurtypeChange = event => {
    const name = event.target.name;
    console.log(event.target.value);
    gurDetails.guarantorType = event.target.value;
    setGuarDetails(gurDetails);
    setGuaratorType({
      type: event.target.value,
      isPartnership:
        event.target.value == "Partership" ||
        event.target.value == "Scotish Firm"
          ? ""
          : "none"
    });
  };

  return (
    <div className={classes.root}>
      <Grid container spacing={2}>
        <Grid item xl={12}>
          <FormControl
            className={classes.formControl}
            style={{ minWidth: 500 }}
          >
            <InputLabel id="demo-simple-select-label">Guarator Type</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={gurDetails.guarantorType}
              native
              onChange={handleGurtypeChange}
            >
              <option aria-label="None" value="" />
              <option value={"Individual"}>Individual</option>
              <option value={"Partership"}>Partership</option>
              <option value={"Scotish Firm"}>Scotish Firm</option>
              <option value={"Solo Trader"}>Solo Trader</option>
            </Select>
          </FormControl>
        </Grid>
        <Grid item>
          <div style={{ display: GuaratorType.isPartnership }}>
            <PartnershipDetails />
          </div>
        </Grid>
      </Grid>
    </div>
  );
}
