import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import Button from "@material-ui/core/Button";
import About from "./About";
import { MemoryRouter as Router } from "react-router";
import { Link, NavLink } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";

const useStyles = makeStyles({
  table: {
    minWidth: 300
  }
});

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

export default function CustomerResultTable(props) {
  const classes = useStyles();
  const [selectedValue, setSelectedValue] = React.useState("");

  const handleChange = event => {
    setSelectedValue(event.target.value);
    console.log(props);
  };

  const securityFound = props.securityData.securityDetails.length;

  return securityFound > 0 ? (
    <div>
      <TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>
                <b>Select</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Name </b>
              </TableCell>
              <TableCell align="center">
                <b>CIN</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Email</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Country</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Contact Number</b>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {props.securityData.securityDetails.map(row => (
              <TableRow key={row.id}>
                <TableCell align="left">
                  <Radio
                    checked={selectedValue === "a"}
                    onChange={handleChange}
                    value="a"
                    name="radio-button-demo"
                    inputProps={{ "aria-label": "A" }}
                  />
                </TableCell>

                <TableCell align="center" component="th" scope="row">
                  {row.customerName}
                </TableCell>
                <TableCell align="center">{row.customerCin}</TableCell>
                <TableCell align="center">{row.customerEmail}</TableCell>
                <TableCell align="center">{row.customerCountry}</TableCell>
                <TableCell align="center">{row.customerPhoneNumber}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Button
        style={{ float: "right" }}
        color="primary"
        variant="contained"
        component={RouterLink}
        to={{
          pathname: "/CreateSecurity",
          state: {
            fromNotifications: true
          }
        }}
      >
        Create Security
      </Button>
    </div>
  ) : (
    <div align="center">No Records found</div>
  );
}
