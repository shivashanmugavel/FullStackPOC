package com.ops_poc.restcontroller.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;

public interface CustomerInformation extends CrudRepository<CustomerDetails, Long>  {
	
	@Query(value = "SELECT * FROM CUSTOMER_INFORMATION  where CUSTOMER_CIN  = :custCin", nativeQuery = 
	        true)
 List<CustomerDetails> getCustomerInformation(@Param("custCin") String cin);

}
