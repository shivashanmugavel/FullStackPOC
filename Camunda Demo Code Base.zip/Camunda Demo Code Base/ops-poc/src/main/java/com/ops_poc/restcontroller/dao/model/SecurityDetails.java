package com.ops_poc.restcontroller.dao.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
public class SecurityDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long applicationID;
	
	private long opsApplicationID;
	private String additionalInformationComments;
	private String estimatedCompletionDate;
	
	
	private String anySuppourtingSecurity;
	private String numberOfSecurity;
	private String taskID;
	
	
	/* working copy of one to one mapping
	@OneToOne(fetch = FetchType.EAGER ,cascade =  CascadeType.ALL)
    @JoinColumn(name = "opsApplicationID")
	
	@JsonManagedReference
   private GuarantorDetails guarantorDetails;
   */
	
	
	public SecurityDetails()
	{
		
	}


	public long getApplicationID() {
		return applicationID;
	}


	public void setApplicationID(long applicationID) {
		this.applicationID = applicationID;
	}


	


	


	public String getAdditionalInformationComments() {
		return additionalInformationComments;
	}


	public void setAdditionalInformationComments(String additionalInformationComments) {
		this.additionalInformationComments = additionalInformationComments;
	}


	public String getEstimatedCompletionDate() {
		return estimatedCompletionDate;
	}


	public void setEstimatedCompletionDate(String estimatedCompletionDate) {
		this.estimatedCompletionDate = estimatedCompletionDate;
	}


	public long getOpsApplicationID() {
		return opsApplicationID;
	}


	public void setOpsApplicationID(long opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}


	public String getAnySuppourtingSecurity() {
		return anySuppourtingSecurity;
	}


	public void setAnySuppourtingSecurity(String anySuppourtingSecurity) {
		this.anySuppourtingSecurity = anySuppourtingSecurity;
	}


	public String getNumberOfSecurity() {
		return numberOfSecurity;
	}


	public void setNumberOfSecurity(String numberOfSecurity) {
		this.numberOfSecurity = numberOfSecurity;
	}


	public String getTaskID() {
		return taskID;
	}


	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}


	
	

}
