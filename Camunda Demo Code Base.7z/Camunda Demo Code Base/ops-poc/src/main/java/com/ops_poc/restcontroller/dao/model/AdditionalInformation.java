package com.ops_poc.restcontroller.dao.model;

public class AdditionalInformation {
	
	private String additionalInformationComments;
	private String estimatedCompletionDate;
	
	
	public AdditionalInformation() {
		
	}


	public String getAdditionalInformationComments() {
		return additionalInformationComments;
	}


	public void setAdditionalInformationComments(String additionalInformationComments) {
		this.additionalInformationComments = additionalInformationComments;
	}


	public String getEstimatedCompletionDate() {
		return estimatedCompletionDate;
	}


	public void setEstimatedCompletionDate(String estimatedCompletionDate) {
		this.estimatedCompletionDate = estimatedCompletionDate;
	}
	
	

}
