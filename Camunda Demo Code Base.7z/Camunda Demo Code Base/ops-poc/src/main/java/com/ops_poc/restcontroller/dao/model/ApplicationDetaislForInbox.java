package com.ops_poc.restcontroller.dao.model;

public class ApplicationDetaislForInbox {

	private  long applicationID;
	private  String numberOfPartners;
	private  String customerName;
	private  String customerPhoneNumber;
	private  String customerContactPerson;
	
	
	
	public ApplicationDetaislForInbox()
	{}
	
	public long getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(long l) {
		this.applicationID = l;
	}
	public String getNumberOfPartners() {
		return numberOfPartners;
	}
	public void setNumberOfPartners(String numberOfPartners) {
		this.numberOfPartners = numberOfPartners;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getCustomerContactPerson() {
		return customerContactPerson;
	}

	public void setCustomerContactPerson(String customerContactPerson) {
		this.customerContactPerson = customerContactPerson;
	}
	
	
}
