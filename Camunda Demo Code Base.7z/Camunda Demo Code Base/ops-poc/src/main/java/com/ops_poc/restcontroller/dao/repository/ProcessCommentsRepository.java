package com.ops_poc.restcontroller.dao.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ops_poc.restcontroller.dao.model.PartnershipDetails;
import com.ops_poc.restcontroller.dao.model.ProcessComments;


public interface ProcessCommentsRepository extends CrudRepository<ProcessComments, Long>  {
	
	List<ProcessComments> findByOpsApplicationID(long opsID);

}
