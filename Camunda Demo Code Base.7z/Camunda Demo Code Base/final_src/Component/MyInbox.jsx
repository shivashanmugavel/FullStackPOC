import React, { Component, useContext, useEffect } from "react";

import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import Button from "@material-ui/core/Button";
import About from "./About";
import { MemoryRouter as Router } from "react-router";
import { Link, NavLink } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
import WorkIcon from "@material-ui/icons/Work";
import VisibilityIcon from "@material-ui/icons/Visibility";
import AssignmentIndRoundedIcon from "@material-ui/icons/AssignmentIndRounded";
import AssignmentTurnedInRoundedIcon from "@material-ui/icons/AssignmentTurnedInRounded";
import LoopIcon from "@material-ui/icons/Loop";
import MaterialTable from "material-table";
import { makeStyles } from "@material-ui/core/styles";
import CircularProgress from "@material-ui/core/CircularProgress";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import Backdrop from "@material-ui/core/Backdrop";

import Delete from "@material-ui/icons/Delete";

import IconButton from "@material-ui/core/IconButton";
import Icon from "@material-ui/core/Icon"; //check

import Tooltip from "@material-ui/core/Tooltip";

import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";

const useStyles = makeStyles(theme => ({
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: "#fff"
  }
}));

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

export default function MyInbox(props) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const handleBackDrop = value => {
    setOpen(value);
  };
  const handleToggle = () => {
    setOpen(!open);
  };

  const { loggedInDetails, setloggedInDetails } = useContext(
    CreateSecurityRequestContext
  );

  const [selectedValue, setSelectedValue] = React.useState("");
  const [inboxDetailsResponse, setInboxDetails] = React.useState({
    inboxDetails: [],
    inboxTaskCount: 0
  });
  const [taskServiceRequest, setTaskServiceRequest] = React.useState({
    taskDetails: {
      taskID: "",
      opsApplicationID: "",
      userID: ""
    }
  });

  const localTaskDetails = { ...taskServiceRequest };

  const userDetails = {
    userName: "",
    userID: loggedInDetails.userID,
    userEmailID: ""
  };

  const handleChange = event => {
    setSelectedValue(event.target.value);
    console.log(props);
  };

  const refreshMyInbox = () => {
    const urlgetInbox = "http://localhost:8084/ops/TaskService/getMyInbox";

    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userDetails)
    };

    const getApplicationID = fetch(urlgetInbox, requestOptions)
      .then(res => res.json())
      .then(data => {
        setInboxDetails({
          inboxDetails: data,
          inboxTaskCount: data.length
        });
        console.log("Inbox data:" + JSON.stringify(data));
        console.log("Inbox count:" + inboxDetailsResponse.inboxTaskCount);
      })
      .catch(err => {
        console.log(err);
      });
  };

  const handleUnClaimClick = async event => {
    handleBackDrop(true);
    localTaskDetails.taskDetails.taskID = event.target.id;
    localTaskDetails.taskDetails.userID = null;
    console.log("handle reassi Click :" + event.target.id);
    console.log("handle reass Click value :" + event.target.value);
    console.log(event.target);

    setTaskServiceRequest(localTaskDetails);

    const tsRequestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(taskServiceRequest.taskDetails)
    };

    const urlUnClaimTask = "http://localhost:8084/ops/TaskService/unClaim";

    console.log("unclaim data:" + JSON.stringify(taskServiceRequest));
    const getApplicationID = await fetch(urlUnClaimTask, tsRequestOptions)
      .then(res => res.json())
      .then(data => {
        console.log("ClaimTask data:" + JSON.stringify(data));
      })
      .catch(err => {
        console.log(err);
      });

    await refreshMyInbox();
    handleBackDrop(false);
  };

  useEffect(() => {
    const urlgetInbox = "http://localhost:8084/ops/TaskService/getMyInbox";

    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userDetails)
    };

    const getApplicationID = fetch(urlgetInbox, requestOptions)
      .then(res => res.json())
      .then(data => {
        setInboxDetails({
          inboxDetails: data,
          inboxTaskCount: data.length
        });
        console.log("Inbox data:" + JSON.stringify(data));
        console.log("Inbox count:" + inboxDetailsResponse.inboxTaskCount);
      })
      .catch(err => {
        console.log(err);
      });
  }, []);

  return inboxDetailsResponse.inboxTaskCount > 0 ? (
    <div>
      <Backdrop className={classes.backdrop} open={open}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell style={{ width: "150px" }}>
                <b>User Action</b>
              </TableCell>

              <TableCell>
                <b>Ops Application ID</b>
              </TableCell>

              <TableCell align="center">
                <b>Task ID </b>
              </TableCell>
              <TableCell align="center">
                <b>Task Owner</b>
              </TableCell>
              <TableCell align="center">
                <b>Priority</b>
              </TableCell>
              <TableCell align="center">
                <b>Number of Security</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Name</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Contact Name</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Contact Number</b>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {inboxDetailsResponse.inboxDetails.map(row => (
              <TableRow key={row.id}>
                <TableCell align="left">
                  <IconButton
                    aria-label="delete"
                    className={classes.margin}
                    color="primary"
                    component={RouterLink}
                    to={{
                      pathname: "/CreateSecurity",
                      state: {
                        formID: row.taskDetails.name,
                        taskID: row.taskDetails.id
                      }
                    }}
                  >
                    <AssignmentTurnedInRoundedIcon
                      size="large"
                      // onClick={handleViewClaimClick}
                    />
                  </IconButton>

                  <IconButton
                    aria-label="delete"
                    className={classes.margin}
                    color="primary"
                    id={row.taskDetails.id}
                    onClick={handleUnClaimClick}
                  >
                    <LoopIcon
                      color="primary"
                      size="large"
                      fontSize="inherit"
                      id={row.taskDetails.id}
                      onClick={handleUnClaimClick}
                    />
                  </IconButton>
                </TableCell>

                <TableCell align="center" component="th" scope="row">
                  {row.appInboxData.applicationID}
                </TableCell>

                <TableCell align="center" component="th" scope="row">
                  {row.taskDetails.id}
                </TableCell>
                <TableCell align="center">{row.taskDetails.assignee}</TableCell>
                <TableCell align="center">{row.taskDetails.priority}</TableCell>
                <TableCell align="center">
                  {row.appInboxData.numberOfPartners}
                </TableCell>
                <TableCell align="center">
                  {row.appInboxData.customerName}
                </TableCell>
                <TableCell align="center">
                  {row.appInboxData.customerContactPerson}
                </TableCell>
                <TableCell align="center">
                  {row.appInboxData.customerPhoneNumber}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  ) : (
    <div align="center">No Task Available to Work</div>
  );
}
