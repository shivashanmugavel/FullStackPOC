package com.ops_poc.restcontroller.dao.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity(name="CustomerInformation")
 
public class CustomerDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;
	private String customerName;
	private String customerCin;
	private String customerEmail;
	private String customerPhoneNumber;
	private String customerCountry;
	private String customerTradingName;
	private String customerLegalEntityType;
	private String customerContactName;
	private String customerAddress;
	private String opsApplicationID;
	
	
	//CREATE TABLE OPS_CUSTOMER_INFO (customerName  VARCHAR(255) ,customerCin VARCHAR(255),customerEmail VARCHAR(255),customerPhoneNumber VARCHAR(255),customerCountry VARCHAR(255) );
	//insert into CustomerDetails values ('GS Tech', '1234567890','gk@gmail.com','9444946185','India');
	
	public CustomerDetails() {
		
	}
	
	
	
	public CustomerDetails(long id, String customerName, String customerCin, String customerEmail,
			String customerPhoneNumber, String customerCountry, String customerTradingName, String customerLegalEntityType , String customerContactName ,String customerAddress  ) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.customerCin = customerCin;
		this.customerEmail = customerEmail;
		this.customerPhoneNumber = customerPhoneNumber;
		this.customerCountry = customerCountry;
		
		this.customerTradingName = customerTradingName;
		this.customerLegalEntityType = customerLegalEntityType ; 
		this.customerContactName = customerContactName ;
		this.customerAddress = customerAddress ;
	}



	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerCin() {
		return customerCin;
	}
	public void setCustomerCin(String customerCin) {
		this.customerCin = customerCin;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}
	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}
	public String getCustomerCountry() {
		return customerCountry;
	}
	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}



	public String getOpsApplicationID() {
		return opsApplicationID;
	}



	public void setOpsApplicationID(String opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}



	public String getCustomerTradingName() {
		return customerTradingName;
	}



	public void setCustomerTradingName(String customerTradingName) {
		this.customerTradingName = customerTradingName;
	}



	public String getCustomerLegalEntityType() {
		return customerLegalEntityType;
	}



	public void setCustomerLegalEntityType(String customerLegalEntityType) {
		this.customerLegalEntityType = customerLegalEntityType;
	}



	public String getCustomerContactName() {
		return customerContactName;
	}



	public void setCustomerContactName(String customerContactName) {
		this.customerContactName = customerContactName;
	}



	public String getCustomerAddress() {
		return customerAddress;
	}



	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	
	
	
	

}
