import React, { Component } from "react";
import { Link, NavLink } from "react-router-dom";
import { BrowserRouter, Route } from "react-router-dom";
import Contact from "./Contact";
import Home from "./Home";
import About from "./About";
import Navbar from "./Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import $ from "jquery";
import Popper from "popper.js";
import SearchSecurity from "./SearchSecurity";
import CreateSecurity from "./CreateSecurity";
import CreateSecurityWrapper from "./CreateSecurityWrapper";
import MyTeamInbox from "./MyTeamInbox";
import MyInbox from "./MyInbox";
import "bootstrap/dist/js/bootstrap.bundle.min"; // must required for boot strap

class Layout extends Component {
  state = {
    count: 0
  };
  render() {
    return (
      <BrowserRouter>
        <div>
          <header>
            <div class="d-flex  bg-danger justify-content-center ">
              <div class="p-3  bg-primary ">
                Hello Jai Ganesha Royal Bank of Scotland !!!
              </div>
            </div>

            <Navbar />
          </header>

          <section>
            <article>
              <Route exact path="/Create Security" component={SearchSecurity} />
              <Route path="/MyTeamInbox" component={MyTeamInbox} />
              <Route path="/CreateSecurity" component={CreateSecurityWrapper} />
              <Route path="/MyInbox" component={MyInbox} />
            </article>
          </section>
        </div>
      </BrowserRouter>
    );
  }
}

export default Layout;
