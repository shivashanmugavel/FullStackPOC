package com.ops_poc.restcontroller.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.ops_poc.restcontroller.dao.model.GuarantorDetails;
import com.ops_poc.restcontroller.dao.model.PartnershipDetails;

public interface GuarantorRepository extends CrudRepository<GuarantorDetails, Long> {

	
	GuarantorDetails findByOpsApplicationID(long opsID);
}
