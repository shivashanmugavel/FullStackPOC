import React, { createContext, useState } from "react";

export const SecurityContext = createContext();

const SecurityContextProvider = props => {
  const [logedInUser, setBooks] = useState("Ganesha");

  const [guarantorDetails, setGuarDetails] = useState({
    guarantorResidence: "Scotland",
    signGuarantorResidence: "Scotland",
    guarantorType: "",
    partnershipDetails: {
      firmName: "SSv Tech",
      tradingName: "SSV",
      CIN: "1234567890",
      partnerAddress: {
        pincode: "635105",
        addressLine1: "1/3 E 90 A ",
        addressLine2: "",
        addressLine3: "",
        addressLine4: "",
        addressLine5: ""
      }
    }
  });

  const WrapperData = { testData: {} };

  const updateTest = ipData => {
    console.log("logging from ip data context" + JSON.stringify(ipData));
    WrapperData.testData = ipData;
    console.log(
      "logging from test data context" + JSON.stringify(WrapperData.testData)
    );

    console.log(
      "logging from wrapper data context" +
        JSON.stringify(WrapperData.testData.partnershipDetails.firmName)
    );
  };

  const getWrapperData = () => {
    console.log(
      "logging from context" +
        JSON.stringify(WrapperData.testData.partnershipDetails)
    );
    return WrapperData;
  };

  return (
    <SecurityContext.Provider
      value={{
        guarantorDetails,
        setGuarDetails,
        getWrapperData,
        updateTest
      }}
    >
      {props.children}
    </SecurityContext.Provider>
  );
};

export default SecurityContextProvider;
