package com.ops_poc.restcontroller.dao.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class GuarantorDetails {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;
	private long opsApplicationID;
	private String guarantorResidence;
	private String signGuarantorResidence;
	private String guarantorType;
	private String partnershipName;
	private String partnerTradingName;
	private String partnerCin;
	@Transient
	private PartnershipDetails partnershipDetails;
	
	                           
	
	/* commenting working piece of one to one mapping"
	@OneToOne(fetch = FetchType.EAGER,
            cascade =  CascadeType.ALL,
            mappedBy = "guarantorDetails")
	
	@JsonBackReference
    private SecurityDetails securityDetails;
    
    */
	
	public GuarantorDetails()
	{
		
	}
	
	
	public GuarantorDetails(String guarantorResidence, String signGuarantorResidence, String guarantorType,
			String partnershipName, String partnerTradingName, String partnerCin) {
		super();
		this.guarantorResidence = guarantorResidence;
		this.signGuarantorResidence = signGuarantorResidence;
		this.guarantorType = guarantorType;
		this.partnershipName = partnershipName;
		this.partnerTradingName = partnerTradingName;
		this.partnerCin = partnerCin;
	}

	
	

	public long getOpsApplicationID() {
		return opsApplicationID;
	}




	public void setOpsApplicationID(long opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}




	




	public String getGuarantorResidence() {
		return guarantorResidence;
	}


	public void setGuarantorResidence(String guarantorResidence) {
		this.guarantorResidence = guarantorResidence;
	}


	public String getSignGuarantorResidence() {
		return signGuarantorResidence;
	}


	public void setSignGuarantorResidence(String signGuarantorResidence) {
		this.signGuarantorResidence = signGuarantorResidence;
	}


	public String getGuarantorType() {
		return guarantorType;
	}


	public void setGuarantorType(String guarantorType) {
		this.guarantorType = guarantorType;
	}


	public String getPartnershipName() {
		return partnershipName;
	}


	public void setPartnershipName(String partnershipName) {
		this.partnershipName = partnershipName;
	}


	public String getPartnerTradingName() {
		return partnerTradingName;
	}


	public void setPartnerTradingName(String partnerTradingName) {
		this.partnerTradingName = partnerTradingName;
	}


	public String getPartnerCin() {
		return partnerCin;
	}


	public void setPartnerCin(String partnerCin) {
		this.partnerCin = partnerCin;
	}


	public PartnershipDetails getPartnershipDetails() {
		return partnershipDetails;
	}


	public void setPartnershipDetails(PartnershipDetails partnershipDetails) {
		this.partnershipDetails = partnershipDetails;
	}


	
	
	
	

}
