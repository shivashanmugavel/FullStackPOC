import React from "react";

const Home = () => {
  return (
    <div>
      <h4>I am in Home </h4>
      <p>Paragraph from Home</p>
    </div>
  );
};

export default Home;
