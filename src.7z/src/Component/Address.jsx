import React, { Component, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Box from "@material-ui/core/Box";
import PersonPinCircleIcon from "@material-ui/icons/PersonPinCircle";
import SearchIcon from "@material-ui/icons/Search";
import Container from "@material-ui/core/Container";

import FormLabel from "@material-ui/core/FormLabel";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput,
  MenuList,
  Icon
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%"
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "left",
    color: theme.palette.text.secondary
  },
  lineHeight: {
    lineHeight: "80px"
  },
  label: {
    textTransform: "capitalize"
  }
}));

export default function Address(props) {
  console.log(props);

  //const { addressDetails, setAddressDetails } = useContext(props.context);

  const classes = useStyles();
  const address = props.address; // direct assignment of abject to a variable . props is received from the parent
  const [value, setValue] = React.useState("female");
  const [GuaratorType, setGuaratorType] = React.useState({
    type: ""
  });

  const handleGurtypeChange = event => {
    const name = event.target.name;
    setGuaratorType({
      type: event.target.value
    });
  };

  // updating parent variables value
  const handleAddressChange = event => {
    // props.onAddressChange(props.address);

    switch (event.target.id) {
      case "PinCode":
        address.pinCode = event.target.value;
        props.onAddressChange(address); // this is function passes from the parent
        break;
      case "AD1":
        console.log("AD1");
        address.addressLine1 = event.target.value;
        props.onAddressChange(address);
        break;
      case "AD2":
        address.addressLine2 = event.target.value;
        props.onAddressChange(address);
        break;
      case "AD3":
        address.addressLine3 = event.target.value;
        props.onAddressChange(address);
        break;
      case "AD4":
        address.addressLine4 = event.target.value;
        props.onAddressChange(address);
        break;
      case "AD5":
        address.addressLine5 = event.target.value;
        props.onAddressChange(address);
        break;
      default:
        return "foo";
    }
  };

  return (
    <div className={classes.root}>
      <Container maxWidth="xl">
        <Grid container item xl={4} xm={3} xs={12} spacing={1}>
          <Grid item xl={12} xs={12}>
            <Typography variant="h6"> Address Details</Typography>
          </Grid>
          <Grid item xs={12} sm={6} xl={6}>
            <FormControl style={{ minWidth: 300 }} autoComplete="off">
              <InputLabel htmlFor="name">PinCode</InputLabel>
              <Input
                error
                autoComplete="off"
                id="PinCode"
                type="text"
                margin="none"
                startAdornment={
                  <InputAdornment position="start">
                    <PersonPinCircleIcon />
                  </InputAdornment>
                }
                onChange={handleAddressChange}
                value={address.pinCode}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} xl={6}>
            <FormControl autoComplete="off">
              <Button
                style={{ lineHeight: "40px" }}
                variant="contained"
                color="primary"
                className={classes.button}
                startIcon={<SearchIcon />}
              >
                Find
              </Button>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl style={{ minWidth: 350 }} autoComplete="off">
              <InputLabel htmlFor="name">Address Line 1 </InputLabel>
              <Input
                id="AD1"
                type="text"
                margin="none"
                onChange={handleAddressChange}
                value={address.addressLine1}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl style={{ minWidth: 350 }} autoComplete="off">
              <InputLabel htmlFor="name">Address Line 2 </InputLabel>
              <Input
                id="AD2"
                type="text"
                margin="none"
                onChange={handleAddressChange}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl style={{ minWidth: 350 }} autoComplete="off">
              <InputLabel htmlFor="name">Address Line 3 </InputLabel>
              <Input
                id="AD3"
                type="text"
                margin="none"
                onChange={handleAddressChange}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl style={{ minWidth: 350 }}>
              <InputLabel htmlFor="name">Address Line 4 </InputLabel>
              <Input
                id="AD4"
                type="text"
                margin="none"
                onChange={handleAddressChange}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl style={{ minWidth: 350 }}>
              <InputLabel htmlFor="name">Address Line 5</InputLabel>
              <Input
                id="AD5"
                type="text"
                margin="none"
                onChange={handleAddressChange}
              />
            </FormControl>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}
