package com.ops_poc.restcontroller.dao.model;

import java.util.List;

import org.camunda.bpm.engine.task.Task;

public class InboxDetails {
	
	private Task taskDetails;
	private ApplicationDetaislForInbox appInboxData;
	public Task getTaskDetails() {
		return taskDetails;
	}
	public void setTaskDetails(Task taskDetails) {
		this.taskDetails = taskDetails;
	}
	public ApplicationDetaislForInbox getAppInboxData() {
		return appInboxData;
	}
	public void setAppInboxData(ApplicationDetaislForInbox appInboxData) {
		this.appInboxData = appInboxData;
	}
	
	
	

}
