import React, { Component, useContext, useState } from "react";
import Login from "./Login";
import Layout from "./Layout";
import CreateSecurity from "./CreateSecurity";
import { BrowserRouter, Route } from "react-router-dom";
//import CreateSecurityWrapper from "./Component/CreateSecurityWrapper";
import SecurityContextProvider from "../Context/SecurityContext";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

const Home = () => {
  const [loggedInDetails, setloggedInDetails] = useState({
    isLogged: "false",
    userName: "",
    userID: "",
    userEmailID: ""
  });
  return (
    <div>
      <CreateSecurityRequestContext.Provider
        value={{
          loggedInDetails,
          setloggedInDetails
        }}
      >
        <Layout />
      </CreateSecurityRequestContext.Provider>
    </div>
  );
};

export default Home;
