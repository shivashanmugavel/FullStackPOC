package com.ops_poc.restcontroller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.HashMap;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.impl.TaskServiceImpl;
import org.camunda.bpm.engine.runtime.MessageCorrelationResult;
import org.camunda.bpm.engine.task.Task;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.ops_poc.dto.CreateSecurityPayLoad;
import com.ops_poc.dto.CreateSecurityRequest;
import com.ops_poc.dto.SecurityDetailsResponse;
import com.ops_poc.restcontroller.dao.model.GuarantorDetails;
import com.ops_poc.restcontroller.dao.model.OpsAddress;
import com.ops_poc.restcontroller.dao.model.PartnershipDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;
import com.ops_poc.restcontroller.dao.repository.GuarantorRepository;
import com.ops_poc.restcontroller.dao.repository.PartnershipRepository;
import com.ops_poc.restcontroller.dao.repository.SecurityRepository;


@RestController
@RequestMapping(value = "/ops")
public class OpsMainController {
	
	
	
	@Autowired
	private Gson gson;
	private long applicationID;
	private long appID;
	
	
	
	private SecurityDetails securityDetails;
	
	@Autowired
	 private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private SecurityRepository secRepository;
	
	@Autowired
	private GuarantorRepository gurRepository;
	
	@Autowired
	private PartnershipRepository parRepository;
	
	
	
	
	
	
	
	
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/CreateSecurity")
	@PostMapping(
	        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}
	)
    public String createSecurity(@RequestBody CreateSecurityPayLoad csp) {
		
		Map<String, Object> objMap = new HashMap<String, Object>();
		
		objMap.put("name","ganesh");
		
		appID = secRepository.getApplicationID();
						
		// Security Details
		SecurityDetails securityDetails = new SecurityDetails();
		securityDetails.setOpsApplicationID(csp.getCreateSecurityRequest().getSecurityDetails().getOpsApplicationID());
		securityDetails.setAnySuppourtingSecurity(csp.getCreateSecurityRequest().getSecurityDetails().getAnySuppourtingSecurity());
		securityDetails.setNumberOfSecurity(csp.getCreateSecurityRequest().getSecurityDetails().getNumberOfSecurity());
		securityDetails.setAdditionalInformationComments(csp.getCreateSecurityRequest().getAdditionalInformation().getAdditionalInformationComments());
		securityDetails.setEstimatedCompletionDate(csp.getCreateSecurityRequest().getAdditionalInformation().getEstimatedCompletionDate());
		
		
		//Guarantor Details
		GuarantorDetails guarantorDetails = new GuarantorDetails();
		guarantorDetails.setOpsApplicationID(csp.getCreateSecurityRequest().getSecurityDetails().getOpsApplicationID());
		guarantorDetails.setGuarantorResidence(csp.getCreateSecurityRequest().getGuarantorDetails().getGuarantorResidence());
		guarantorDetails.setSignGuarantorResidence(csp.getCreateSecurityRequest().getGuarantorDetails().getSignGuarantorResidence());
		guarantorDetails.setGuarantorType(csp.getCreateSecurityRequest().getGuarantorDetails().getGuarantorType());
		
		//Partner Detaisl
		PartnershipDetails partnershipDetails = new PartnershipDetails();
		partnershipDetails.setOpsApplicationID(csp.getCreateSecurityRequest().getSecurityDetails().getOpsApplicationID());
		partnershipDetails.setCIN(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getCIN());
		partnershipDetails.setFirmName(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getFirmName());
		partnershipDetails.setTradingName(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getTradingName());
		
		
		//Address Detaisl
		OpsAddress opsAddress = new OpsAddress();
		opsAddress.setOpsApplicationID(csp.getCreateSecurityRequest().getSecurityDetails().getOpsApplicationID());
		opsAddress.setPinCode(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getPartnerAddress().getPinCode());
		opsAddress.setAddressLine1(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getPartnerAddress().getAddressLine1());
		opsAddress.setAddressLine2(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getPartnerAddress().getAddressLine2());
		opsAddress.setAddressLine3(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getPartnerAddress().getAddressLine3());
		opsAddress.setAddressLine4(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getPartnerAddress().getAddressLine4());
		opsAddress.setAddressLine5(csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getPartnerAddress().getAddressLine5());
		
		
		
		System.out.println("cin code "  + csp.getCreateSecurityRequest().getGuarantorDetails().getPartnershipDetails().getCIN());
		
		partnershipDetails.setPartnerAddress(opsAddress);
		
		secRepository.save(securityDetails);
		gurRepository.save(guarantorDetails);
		parRepository.save(partnershipDetails);
		
		
		//Triggering workflow
		 SecurityDetails applicationID=secRepository.save(securityDetails);
		 objMap.put("bkey",csp.getCreateSecurityRequest().getSecurityDetails().getOpsApplicationID());
		 objMap.put("applicationID",applicationID.getApplicationID()  ) ;
		 
	      runtimeService.startProcessInstanceByKey("ops_wf1",objMap);
		 
	  System.out.println("haiii csp "  + csp.getCreateSecurityRequest().getSecurityDetails().getApplicationID());
	 return  gson.toJson("Ops Application  id "+ csp.getCreateSecurityRequest().getSecurityDetails().getOpsApplicationID() );
              }
	
	
	
	
	
	
	@CrossOrigin(origins = "http://localhost:3000")
	@PostMapping(
	        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}
	)
	@RequestMapping("/GetSecurityDetails")
    public SecurityDetailsResponse  getSecurityDetails(@RequestBody CreateSecurityPayLoad csp)
	{
		
		System.out.println("sec request  " + csp.getCreateSecurityRequest().getSecurityDetails().getTaskID() );
		
		SecurityDetails tempOpsAPPID = secRepository.findBytaskID(csp.getCreateSecurityRequest().getSecurityDetails().getTaskID());
		
		System.out.println("get sec detaisl ops appd id in  " + tempOpsAPPID.getOpsApplicationID() );
		
		SecurityDetailsResponse secDetailsResponse = new SecurityDetailsResponse();
		PartnershipDetails partDetailsResponse = new PartnershipDetails();
		GuarantorDetails gurDetaislResponse = new GuarantorDetails();
		
				
		try {
			
			
			securityDetails= secRepository.findByOpsApplicationID(tempOpsAPPID.getOpsApplicationID());
			partDetailsResponse = parRepository.findByOpsApplicationID(tempOpsAPPID.getOpsApplicationID());
			gurDetaislResponse = gurRepository.findByOpsApplicationID(tempOpsAPPID.getOpsApplicationID());
			
			gurDetaislResponse.setPartnershipDetails(partDetailsResponse);
			
			secDetailsResponse.setSecurityDetails(securityDetails);
			secDetailsResponse.setGuarantorDetails(gurDetaislResponse);
			
			csp.setSecurityDetailsResponse(secDetailsResponse);
			
			
			
			
			System.out.println("Testing value " + securityDetails );
			//gson.toJson(securityDetailsRespoanse);
			
 
 
             return  secDetailsResponse; 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return secDetailsResponse;
		
    
	}

	

}
