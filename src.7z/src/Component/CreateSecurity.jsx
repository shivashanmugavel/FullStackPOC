import React, { Component, useContext, useEffect } from "react";
import { useHistory } from "react-router-dom";
import Contact from "./Contact";
import { BrowserRouter, Route } from "react-router-dom";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import PhoneIcon from "@material-ui/icons/Phone";
//import FavoriteIcon from "@material-ui/icons/Favorite";
import PersonPinIcon from "@material-ui/icons/PersonPin";
import HelpIcon from "@material-ui/icons/Help";
import ShoppingBasket from "@material-ui/icons/ShoppingBasket";
import ThumbDown from "@material-ui/icons/ThumbDown";
import ThumbUp from "@material-ui/icons/ThumbUp";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import AccountBalanceOutlinedIcon from "@material-ui/icons/AccountBalanceOutlined";
import CustomerDetails from "./CustomerDetails";
import GuarantorDetails from "./GuarantorDetails";
import SecurityDetails from "./SecurityDetails";
import AdditionalInformation from "./AdditionalInformation";
import SecurityContextProvider from "../Context/SecurityContext";
import axios from "axios";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";
import { Redirect } from "react-router-dom";

import Button from "@material-ui/core/Button";
import Icon from "@material-ui/core/Icon";
import SendIcon from "@material-ui/icons/Send";
import { SecurityContext } from "../Context/SecurityContext";
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-force-tabpanel-${index}`}
      aria-labelledby={`scrollable-force-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired
};

function a11yProps(index) {
  return {
    id: `scrollable-force-tab-${index}`,
    "aria-controls": `scrollable-force-tabpanel-${index}`
  };
}

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper
  }
}));
const CreateSecurity = () => {
  const CreateSecurityPayload = {
    createSecurityRequest: {
      customerDetails: {},
      guarantorDetails: {},
      securityDetails: {},
      additionalInformation: {}
    }
  };
  const classes = useStyles();
  const {
    guarantorDetails,
    setGuarDetails,
    securityDetails,
    setSecurityDetails,
    additionalInformation
  } = useContext(CreateSecurityRequestContext);

  const [value, setValue] = React.useState(0);
  const [applicationID, setApplicationID] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const secDetails = { ...securityDetails };

  const history = useHistory();

  /*  const btn_handleCreateSecurity = () => {
    CreateSecurityPayload.GuarantorDetails = guarantorDetails;
    console.log(CreateSecurityPayload);
    //const url = "https://jsonplaceholder.typicode.com/users";
    const url = "http://localhost:8080/ops/CreateSecurity";
    const response = axios.post(url, CreateSecurityPayload).then(response => {
      //setSecDetails({ securityDetails: response.data, toDisplay: "" });
      console.log(response);
    });
  }; */

  const btn_handleCreateSecurity = () => {
    CreateSecurityPayload.createSecurityRequest.guarantorDetails = guarantorDetails;
    CreateSecurityPayload.createSecurityRequest.securityDetails = securityDetails;
    CreateSecurityPayload.createSecurityRequest.additionalInformation = additionalInformation;
    console.log(CreateSecurityPayload);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(CreateSecurityPayload)
    };
    //const url = "https://jsonplaceholder.typicode.com/users";
    const url = "http://localhost:8084/ops/CreateSecurity";
    const response = fetch(url, requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data);
      });

    // history.push("/Create Security");
  };

  useEffect(() => {
    const urlAppid =
      "http://localhost:8084/ops/GenericService/getApplicationId";
    const getApplicationID = fetch(urlAppid)
      .then(res => res.json())
      .then(data => {
        console.log("appid:" + data);
        const result = data;
        setApplicationID(result);
        secDetails.opsApplicationID = result;
        setSecurityDetails(secDetails);
      });
  }, []);

  return (
    <div className={classes.root}>
      <div
        style={{
          float: "right",
          marginRight: "20px"
        }}
      >
        Application ID : {applicationID}
      </div>
      <AppBar position="static">
        <Tabs
          value={value}
          onChange={handleChange}
          variant="scrollable"
          scrollButtons="on"
          indicatorColor="secondary"
          //textColor="primary"
          aria-label="scrollable force tabs example"
        >
          <Tab
            label="Customer Details"
            icon={<PhoneIcon />}
            {...a11yProps(0)}
            wrapped
          />
          <Tab
            label="Guarantor Details"
            icon={<AccountBalanceOutlinedIcon />}
            {...a11yProps(1)}
          />
          <Tab
            label="Security Details"
            icon={<PersonPinIcon />}
            {...a11yProps(2)}
          />
          <Tab
            label="Additional Information"
            icon={<HelpIcon />}
            {...a11yProps(3)}
          />
          {/* <Tab label="Rate" icon={<ShoppingBasket />} {...a11yProps(4)} />
          <Tab label="Item Six" icon={<ThumbDown />} {...a11yProps(5)} />
          <Tab label="Item Seven" icon={<ThumbUp />} {...a11yProps(6)} /> */}
        </Tabs>
      </AppBar>
      <TabPanel value={value} index={0}>
        <SecurityContextProvider>
          <CustomerDetails />
        </SecurityContextProvider>
      </TabPanel>
      <TabPanel value={value} index={1}>
        <SecurityContextProvider>
          <GuarantorDetails />
        </SecurityContextProvider>
      </TabPanel>
      <TabPanel value={value} index={2}>
        <SecurityDetails />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <AdditionalInformation />
      </TabPanel>
      {/* <TabPanel value={value} index={4}>
        Item Five
      </TabPanel>
      <TabPanel value={value} index={5}>
        Item Six
      </TabPanel>
      <TabPanel value={value} index={6}>
        Item Seven
      </TabPanel> */}
      <div
        style={{
          float: "right",
          marginRight: "20px",
          marginBottom: "30px"
        }}
      >
        <Button
          variant="contained"
          size="medium"
          color="primary"
          style={{ width: "200px", backgroundColor: "green" }}
          className={classes.button}
          endIcon={<SendIcon />}
          onClick={btn_handleCreateSecurity}
        >
          Create Sucurity
        </Button>
      </div>
    </div>
  );
};

export default CreateSecurity;
