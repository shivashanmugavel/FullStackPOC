import React from "react";
import { Link, NavLink } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import Menu from "@material-ui/core/Menu";
//import "bootstrap/dist/css/bootstrap.css";

const Navbar = () => {
  const StyledMenu = withStyles({
    paper: {
      border: "1px solid #d3d4d5"
    }
  })(props => (
    <Menu
      elevation={0}
      getContentAnchorEl={null}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center"
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "center"
      }}
      {...props}
    />
  ));

  return (
    /* this route will reload a entire page -- this is not a good design
    <div>
      <a> God's Fun time</a>
      <ul>
        <li>
          <a href="/">Homee</a>
        </li>
        <li>
          <a href="/About us">About US</a>
        </li>
        <li>
          <a href="/Contact US">Contact Us</a>
        </li>
      </ul>
    </div>
    */

    // alternate solution for above problem

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
      <div class="navbar-nav">
        <div class="dropdown">
          <button
            type="button"
            class="btn btn-primary dropdown-toggle"
            data-toggle="dropdown"
          >
            Menu
          </button>
          <div class="dropdown-menu MenuWidth">
            <div class="d-flex MenuWidth">
              <section>
                <ul>
                  <a>
                    <Link to="/Create Security">Create Security </Link>
                  </a>
                  <li>
                    <Link to="/About us" class="dropdown-menu">
                      My Inbox
                    </Link>
                  </li>
                  <li>
                    <Link to="/MyTeamInbox">My Team Inbox</Link>
                  </li>
                  <li>
                    <Link to="/MyInbox">My Inbox</Link>
                  </li>
                  <li>
                    <div class="d-inline-flex">
                      <Link to="/Contact US">Security dashboard</Link>
                    </div>
                  </li>
                </ul>
              </section>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
