import React from "react";
import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import Box from "@material-ui/core/Box";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Paper from "@material-ui/core/Paper";

import Grid from "@material-ui/core/Grid";
import FormLabel from "@material-ui/core/FormLabel";
import FormHelperText from "@material-ui/core/FormHelperText";

import FormControlLabel from "@material-ui/core/FormControlLabel";
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import CustomerResultTable from "./CustomerResultTable";
import axios from "axios";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary
  }
}));
//component starts here
const SearchSecurity = () => {
  const classes = useStyles();

  const [value, setValue] = React.useState();

  const [cinValue, setCinValue] = React.useState();

  const [securityDetails, setSecDetails] = React.useState({
    securityDetails: [],
    toDisplay: "none"
  });

  const [searchType, setSearchType] = React.useState({
    cin: "none",
    customerName: "none"
  });

  const handleChange = event => {
    setValue(event.target.value);
  };

  /* const handleSearchSubmit = event => {
    const url = "https://jsonplaceholder.typicode.com/users";
    const response = axios.get(url).then(response => {
      setSecDetails({ securityDetails: response.data, toDisplay: "" });
      console.log(securityDetails);
      // console.log(response);
    });
  }; */

  const handleSearchSubmit = event => {
    const req = { customerCin: cinValue };

    const url =
      "http://localhost:8084/ops/GenericService/GetCustomerDetailsByCin";

    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",

        "Access-Control-Allow-Origin": "http://localhost:3000",

        "Access-Control-Allow-Methods": "POST"
      },
      body: JSON.stringify(req)
    };

    console.log(requestOptions.body);
    const response = fetch(url, requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data);
        setSecDetails({ securityDetails: data, toDisplay: "" });
        console.log(securityDetails);
      });
  };

  const handleSearchType = event => {
    console.log(event);
    setValue(event.target.value);

    if (event.target.value === "CIN number") {
      setSearchType({
        cin: "",
        customerName: "none"
      });
    }

    if (event.target.value === "Customer name") {
      setSearchType({
        cin: "none",
        customerName: ""
      });
    }
  };

  const handleOnInput = event => {
    setCinValue(event.target.value);
    console.log(cinValue);
  };

  return (
    <div>
      <Box m={10} justifyContent="center">
        <AppBar position="static">
          <Toolbar>Customer Search</Toolbar>
        </AppBar>

        <Paper style={{ margin: 10 }} elevation={5}>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              margin: 20,
              padding: 20
            }}
          >
            <form style={{ width: "50%" }}>
              <h1>Customer Search ..</h1>

              <FormControl
                component="fieldset"
                className={classes.formControl}
                style={{ marginTop: 50 }}
              >
                <FormLabel component="legend">
                  <b>Search Customer By </b>
                </FormLabel>

                <RadioGroup
                  row
                  aria-label="gender"
                  name="gender1"
                  value={value}
                  onChange={handleSearchType}
                >
                  <FormGroup row>
                    <FormControlLabel
                      value="CIN number"
                      control={<Radio />}
                      label="CIN number"
                    />
                    <FormControlLabel
                      value="Customer name"
                      control={<Radio />}
                      label="Customer name"
                    />
                  </FormGroup>
                </RadioGroup>
              </FormControl>

              <FormControl
                margin="normal"
                fullWidth
                style={{ display: searchType.cin }}
                onChange={handleOnInput}
              >
                <InputLabel htmlFor="name">CIN Number</InputLabel>
                <Input id="name" type="number" value={cinValue} />
              </FormControl>

              <FormControl
                margin="normal"
                fullWidth
                style={{ display: searchType.customerName }}
              >
                <InputLabel htmlFor="email">Customer Name</InputLabel>
                <Input id="email" type="email" value={value} />
              </FormControl>

              <Button
                style={{ display: "block" }}
                variant="contained"
                color="primary"
                size="medium"
                onClick={handleSearchSubmit}
              >
                Search
              </Button>
            </form>
          </div>
          <div style={{ display: securityDetails.toDisplay }}>
            <CustomerResultTable securityData={securityDetails} />
          </div>
        </Paper>
      </Box>
    </div>
  );
};

export default SearchSecurity;
