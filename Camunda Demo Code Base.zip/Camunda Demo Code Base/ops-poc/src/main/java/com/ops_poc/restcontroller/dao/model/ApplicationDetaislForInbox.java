package com.ops_poc.restcontroller.dao.model;

public class ApplicationDetaislForInbox {

	private  String applicationID;
	private  String numberOfPartners;
	public String getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(String applicationID) {
		this.applicationID = applicationID;
	}
	public String getNumberOfPartners() {
		return numberOfPartners;
	}
	public void setNumberOfPartners(String numberOfPartners) {
		this.numberOfPartners = numberOfPartners;
	}
	
	
}
