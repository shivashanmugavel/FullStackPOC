import React from "react";

const About = props => {
  const receivedValue = props.location.state;
  const [fromNotifications, setNote] = React.useState(receivedValue);

  console.log(receivedValue);
  console.log(fromNotifications);

  return (
    <div>
      <h4>I am in About </h4>
      <p>Paragraph from About</p>
    </div>
  );
};

export default About;
