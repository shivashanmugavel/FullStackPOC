package com.ops_poc.restcontroller.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.ops_poc.restcontroller.dao.model.*;

import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;



public interface SecurityRepository extends CrudRepository<SecurityDetails, Long> {
	
	 @Query(value = "SELECT nextval('HIBERNATE_SEQUENCE') ", nativeQuery = 
		        true)
		 Long getApplicationID();
	 
	 SecurityDetails findByOpsApplicationID(long opsID);

	
	 
	 
}
