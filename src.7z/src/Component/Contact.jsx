import React from "react";

const Contact = () => {
  return (
    <div>
      <h4>I am in Contact </h4>
      <p>Paragraph from Contact</p>
    </div>
  );
};

export default Contact;
