import React, { Component, useContext, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import { BrowserRouter, Route } from "react-router-dom";
import Contact from "./Contact";
import Home from "./Home";
import About from "./About";
import Navbar from "./Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import $ from "jquery";
import Popper from "popper.js";
import SearchSecurity from "./SearchSecurity";
import CreateSecurity from "./CreateSecurity";
import CreateSecurityWrapper from "./CreateSecurityWrapper";
import MyTeamInbox from "./MyTeamInbox";
import MyInbox from "./MyInbox";
import Login from "./Login";
import SecurityContextProvider from "../Context/SecurityContext";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import "bootstrap/dist/js/bootstrap.bundle.min"; // must required for boot strap

export default function Layout(props) {
  const { loggedInDetails, setloggedInDetails } = useContext(
    CreateSecurityRequestContext
  );

  console.log("isloggedin  " + loggedInDetails.isLogged);
  return (
    <BrowserRouter>
      <div>
        <header>
          <div class="headerBG" style={{ height: "80px" }}>
            <div class="floatRight">
              {
                <img
                  src={require("./nw2.jpg")}
                  alt="W3Schools.com"
                  width="100"
                  height="90"
                />
              }
            </div>
          </div>

          {loggedInDetails.isLogged == "true" ? (
            <Navbar
              menuVisibility={false}
              userDetails={loggedInDetails.userID}
            />
          ) : null}
        </header>
        {loggedInDetails.isLogged == "false" ? (
          <SecurityContextProvider>
            <Login></Login>
          </SecurityContextProvider>
        ) : null}

        <section>
          <article>
            <Route exact path="/Create Security" component={SearchSecurity} />
            <Route path="/MyTeamInbox" component={MyTeamInbox} />
            <Route path="/CreateSecurity" component={CreateSecurityWrapper} />
            <Route path="/MyInbox" component={MyInbox} />
          </article>
        </section>
      </div>
    </BrowserRouter>
  );
}

//export default Layout;
