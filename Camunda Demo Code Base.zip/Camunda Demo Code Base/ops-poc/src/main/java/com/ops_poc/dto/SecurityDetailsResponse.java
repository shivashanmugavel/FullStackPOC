package com.ops_poc.dto;

import org.springframework.beans.factory.annotation.Autowired;

import com.ops_poc.restcontroller.dao.model.AdditionalInformation;
import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.GuarantorDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;

public class SecurityDetailsResponse {
	
	

	@Autowired
	private GuarantorDetails guarantorDetails;



	@Autowired
	private SecurityDetails securityDetails;
	
	@Autowired
	private AdditionalInformation additionalInformation;
	
	@Autowired
	private CustomerDetails customerDetails;
	
	public SecurityDetailsResponse() {
		super();
		
	}

	
	
	
	
	public GuarantorDetails getGuarantorDetails() {
		return guarantorDetails;
	}
	
	
	public void setGuarantorDetails(GuarantorDetails guarantorDet) {
		this.guarantorDetails = guarantorDet;
	}
	
	
	public SecurityDetails getSecurityDetails() {
		return securityDetails;
	}


	public void setSecurityDetails(SecurityDetails securityDetails) {
		this.securityDetails = securityDetails;
	}


	public AdditionalInformation getAdditionalInformation() {
		return additionalInformation;
	}


	public void setAdditionalInformation(AdditionalInformation additionalInformation) {
		this.additionalInformation = additionalInformation;
	}





	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}





	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}


	


}
