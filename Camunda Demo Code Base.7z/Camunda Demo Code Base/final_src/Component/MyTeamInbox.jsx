import React, { Component, useContext, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import Button from "@material-ui/core/Button";
import About from "./About";
import { MemoryRouter as Router } from "react-router";
import { Link, NavLink } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";
import WorkIcon from "@material-ui/icons/Work";
import VisibilityIcon from "@material-ui/icons/Visibility";
import AssignmentIndRoundedIcon from "@material-ui/icons/AssignmentIndRounded";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import IconButton from "@material-ui/core/IconButton";

import Tooltip from "@material-ui/core/Tooltip";

import Icon from "@material-ui/core/Icon"; //check

const useStyles = makeStyles(theme => ({
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: "#fff"
  }
}));

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

export default function MyTeamInbox(props) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const { loggedInDetails, setloggedInDetails } = useContext(
    CreateSecurityRequestContext
  );

  const handleBackDrop = value => {
    setOpen(value);
  };
  const [selectedValue, setSelectedValue] = React.useState("");
  const [inboxDetailsResponse, setInboxDetails] = React.useState({
    inboxDetails: [],
    inboxTaskCount: 0
  });
  const [taskServiceRequest, setTaskServiceRequest] = React.useState({
    taskDetails: {
      taskID: "",
      opsApplicationID: "",
      userID: loggedInDetails.userID
    }
  });

  const localTaskDetails = { ...taskServiceRequest };

  const userDetails = {
    userName: "",
    userID: loggedInDetails.userID,
    userEmailID: ""
  };

  const handleChange = event => {
    setSelectedValue(event.target.value);
    console.log(props);
  };

  const refreshTeamInbox = () => {
    console.log("Inbox refreshed:");

    const urlgetInbox = "http://localhost:8084/ops/TaskService/getMyTeamInbox";
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userDetails)
    };
    const getApplicationID = fetch(urlgetInbox, requestOptions)
      .then(res => res.json())
      .then(data => {
        setInboxDetails({
          inboxDetails: data,
          inboxTaskCount: data.length
        });
        console.log("Inbox data:" + JSON.stringify(data));
        console.log("Inbox count:" + inboxDetailsResponse.inboxTaskCount);
        //setApplicationID(result);
        //secDetails.opsApplicationID = result;
        // setSecurityDetails(secDetails);
      });
  };

  const handleClaimClick = async event => {
    localTaskDetails.taskDetails.taskID = event.target.id;
    //localTaskDetails.taskDetails.userID =

    setTaskServiceRequest(localTaskDetails);

    const tsRequestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify(taskServiceRequest.taskDetails)
    };

    const urlClaimTask = "http://localhost:8084/ops/TaskService/claimTask";

    console.log("ClaimTask data:" + JSON.stringify(taskServiceRequest));
    const getApplicationID = await fetch(urlClaimTask, tsRequestOptions)
      .then(res => res.json())
      .then(data => {
        console.log("ClaimTask data:" + JSON.stringify(data));
      })
      .catch(err => {
        console.log(err);
      });
    await refreshTeamInbox();
    handleBackDrop(false);
  };

  const handleViewClick = event => {
    localTaskDetails.taskDetails.taskId = event.target.id;

    console.log("req data :" + event.target.id);

    setTaskServiceRequest(localTaskDetails);

    const tsRequestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(taskServiceRequest)
    };

    const urlClaimTask = "http://localhost:8084/ops/TaskService/getMyTeamInbox";

    console.log("ClaimTask data:" + JSON.stringify(taskServiceRequest));
    const getApplicationID = fetch(urlClaimTask, taskServiceRequest)
      .then(res => res.json())
      .then(data => {
        console.log("ClaimTask data:" + JSON.stringify(data));
      })
      .catch(err => {
        console.log(err);
      });
  };

  useEffect(() => {
    const urlgetInbox = "http://localhost:8084/ops/TaskService/getMyTeamInbox";
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userDetails)
    };
    const getApplicationID = fetch(urlgetInbox, requestOptions)
      .then(res => res.json())
      .then(data => {
        setInboxDetails({
          inboxDetails: data,
          inboxTaskCount: data.length
        });
        console.log("Inbox data:" + JSON.stringify(data));
        console.log("Inbox count:" + inboxDetailsResponse.inboxTaskCount);
        //setApplicationID(result);
        //secDetails.opsApplicationID = result;
        // setSecurityDetails(secDetails);
      })
      .catch(err => {
        console.log(err);
      });
  }, []);

  return inboxDetailsResponse.inboxTaskCount > 0 ? (
    <div>
      <Backdrop className={classes.backdrop} open={open}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell style={{ width: "150px" }}>
                <b>User Action</b>
              </TableCell>
              <TableCell>
                <b>Ops Application ID</b>
              </TableCell>
              <TableCell align="center">
                <b>Task ID </b>
              </TableCell>
              <TableCell align="center">
                <b>Task Owner</b>
              </TableCell>
              <TableCell align="center">
                <b>Priority</b>
              </TableCell>
              <TableCell align="center">
                <b>Number of Security</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Name</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Contact Name</b>
              </TableCell>
              <TableCell align="center">
                <b>Customer Contact Number</b>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {inboxDetailsResponse.inboxDetails.map(row => (
              <TableRow key={row.id}>
                <TableCell align="left">
                  <IconButton aria-label="delete" className={classes.margin}>
                    <Tooltip title="View Security" arrow>
                      <VisibilityIcon
                        color="primary"
                        size="large"
                        fontSize="inherit"
                        onClick={handleViewClick}
                      />
                    </Tooltip>
                  </IconButton>

                  <IconButton
                    aria-label="delete"
                    className={classes.margin}
                    color="primary"
                    id={row.taskDetails.id}
                    onClick={handleClaimClick}
                  >
                    <AssignmentIndRoundedIcon
                      id={row.taskDetails.id}
                      size="large"
                      onClick={handleClaimClick}
                    />
                  </IconButton>
                </TableCell>

                <TableCell align="center" component="th" scope="row">
                  {row.appInboxData.applicationID}
                </TableCell>
                <TableCell align="center" component="th" scope="row">
                  {row.taskDetails.id}
                </TableCell>
                <TableCell align="center">{row.customerCin}</TableCell>
                <TableCell align="center">{row.taskDetails.priority}</TableCell>
                <TableCell align="center">
                  {row.appInboxData.numberOfPartners}
                </TableCell>
                <TableCell align="center">
                  {row.appInboxData.customerName}
                </TableCell>
                <TableCell align="center">
                  {row.appInboxData.customerContactPerson}
                </TableCell>
                <TableCell align="center">
                  {row.appInboxData.customerPhoneNumber}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  ) : (
    <div align="center">No Task Available to Claim</div>
  );
}
