import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import ListItemText from "@material-ui/core/ListItemText";
import ListItem from "@material-ui/core/ListItem";
import List from "@material-ui/core/List";
import Divider from "@material-ui/core/Divider";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import CloseIcon from "@material-ui/icons/Close";
import Slide from "@material-ui/core/Slide";
import Address from "./Address";

import {
  FormControl,
  InputLabel,
  Input,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  Grid
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  appBar: {
    position: "relative"
  },
  title: {
    marginLeft: theme.spacing(2),
    flex: 1
  }
}));

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function AddSupportingSecurity() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Button variant="contained" color="primary" onClick={handleClickOpen}>
        Add Supporting Security
      </Button>
      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>

            <Button autoFocus color="inherit" onClick={handleClose}>
              save
            </Button>
          </Toolbar>
        </AppBar>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            margin: 20,
            padding: 20
          }}
        >
          <form style={{ width: "50%" }}>
            <FormControl
              className={classes.formControl}
              style={{ minWidth: 500 }}
            >
              <InputLabel id="demo-simple-select-label">
                Security Type
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                //value={GuaratorType.type}
                native
                //onChange={handleGurtypeChange}
              >
                <option aria-label="None" value="" />
                <option value={"Legal Charge"}>Legal Charge</option>
                <option value={"Others"}>Others</option>
              </Select>
            </FormControl>

            <FormControl
              className={classes.formControl}
              style={{ minWidth: 500 }}
            >
              <InputLabel id="demo-simple-select-label">
                Security Status
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                //value={GuaratorType.type}
                native
                //onChange={handleGurtypeChange}
              >
                <option aria-label="None" value="" />
                <option value={"New / Offered"}>New / Offered</option>
                <option value={"Existing"}>Existing</option>
              </Select>
            </FormControl>
            <FormControl margin="normal" fullWidth>
              <InputLabel htmlFor="name">Forename</InputLabel>
              <Input id="name" type="text" />
            </FormControl>

            <FormControl margin="normal" fullWidth>
              <InputLabel htmlFor="email">Security ID Number</InputLabel>
              <Input id="email" type="text" />
            </FormControl>

            <Button variant="contained" color="primary" size="medium">
              Add Supporting Security
            </Button>
          </form>
        </div>
      </Dialog>
    </div>
  );
}
