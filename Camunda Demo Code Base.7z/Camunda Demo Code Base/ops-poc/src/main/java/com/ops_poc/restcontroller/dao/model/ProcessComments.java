package com.ops_poc.restcontroller.dao.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ProcessComments {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long ID;
	
	private String userName;
	private String comments;
	private String commentsDate;
	private String userAction;
	private Long opsApplicationID;
	private String processStage;
	
	
	public ProcessComments()
	{
		
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCommentsDate() {
		return commentsDate;
	}

	public void setCommentsDate(String commentsDate) {
		this.commentsDate = commentsDate;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public Long getOpsApplicationID() {
		return opsApplicationID;
	}

	public void setOpsApplicationID(Long opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}

	public long getID() {
		return ID;
	}

	public void setID(long iD) {
		ID = iD;
	}

	public String getProcessStage() {
		return processStage;
	}

	public void setProcessStage(String processStage) {
		this.processStage = processStage;
	}
	
	
	
	
	
	

}
