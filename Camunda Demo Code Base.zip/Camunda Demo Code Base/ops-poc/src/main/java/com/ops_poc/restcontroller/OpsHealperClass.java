package com.ops_poc.restcontroller;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

import com.ops_poc.restcontroller.dao.repository.SecurityRepository;


@Component
public class  OpsHealperClass {
	
	@Autowired
	private  SecurityRepository secRepository1;

	public SecurityRepository getSecRepository1() {
		return secRepository1;
	}

	public void setSecRepository1(SecurityRepository secRepository1) {
		this.secRepository1 = secRepository1;
	}
	
	
		
}
