import React, { Component, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import { SecurityContext } from "../Context/SecurityContext";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%"
  },
  paper: {
    padding: theme.spacing(1),
    textAlign: "center",
    color: theme.palette.text.secondary
  }
}));

const CustomerDetails = () => {
  const classes = useStyles();
  const val = 1;

  const { logedInUser } = useContext(SecurityContext);

  //const loggedInUser = useContext(SecurityContext);
  console.log("hai  " + logedInUser);

  function FormRow() {
    return (
      <React.Fragment>
        <Grid item xs={4}>
          <Paper className={classes.paper}>item</Paper>
        </Grid>
        <Grid item xs={4}>
          <Paper className={classes.paper}>item</Paper>
        </Grid>
        <Grid item xs={4}>
          <Paper className={classes.paper}>item</Paper>
        </Grid>
      </React.Fragment>
    );
  }

  return (
    <div className={classes.root}>
      <ExpansionPanel>
        <ExpansionPanelSummary
          expandIcon={<ExpandMoreIcon />}
          style={{ backgroundColor: "#2196f3" }}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography className={classes.heading}>
            Customer {logedInUser} Information
          </Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Grid container spacing={1}>
            <Grid container item xs={12} spacing={3}>
              <Grid item xs={12}>
                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="name">Customer Name </InputLabel>
                  <Input
                    id="name"
                    type="text"
                    readOnly
                    defaultValue="Royal Bank of Scotland"
                    startAdornment={
                      <InputAdornment position="start">
                        <AccountBalanceIcon />
                      </InputAdornment>
                    }
                  />
                </FormControl>
              </Grid>
              <Grid item xs={3}>
                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="name">Trading Name </InputLabel>
                  <Input
                    id="name"
                    type="text"
                    readOnly
                    defaultValue="RBS Bank"
                    startAdornment={
                      <InputAdornment position="start">
                        <TrendingUpIcon />
                      </InputAdornment>
                    }
                  />
                </FormControl>
              </Grid>

              <Grid item xs={3}>
                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="name">CIN </InputLabel>
                  <Input
                    id="name"
                    type="text"
                    readOnly
                    defaultValue="RBS Bank"
                    startAdornment={
                      <InputAdornment position="start">
                        <AccountBoxIcon />
                      </InputAdornment>
                    }
                  />
                </FormControl>
              </Grid>

              <Grid item xs={3}>
                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="name">Legal Entity Type </InputLabel>
                  <Input
                    id="name"
                    type="text"
                    readOnly
                    defaultValue="RBS Bank"
                  />
                </FormControl>
              </Grid>
              <Grid item xs={3}>
                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="name">Contact Name </InputLabel>
                  <Input
                    id="name"
                    type="text"
                    readOnly
                    defaultValue="RBS Bank"
                  />
                </FormControl>
              </Grid>

              <Grid item xs={3}>
                <FormControl margin="normal" fullWidth>
                  <InputLabel htmlFor="name">Contact Address </InputLabel>
                  <Input
                    id="name"
                    type="text"
                    readOnly
                    defaultValue="RBS Bank
                    
                    1/292 , Nethaji Nagar 
                    
                    Zuzuvadi"
                    multiline
                  />
                </FormControl>
              </Grid>
            </Grid>
          </Grid>
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
  );
};

export default CustomerDetails;
