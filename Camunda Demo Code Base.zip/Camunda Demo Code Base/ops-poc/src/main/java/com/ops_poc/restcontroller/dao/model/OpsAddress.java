package com.ops_poc.restcontroller.dao.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
public class OpsAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;
	
	private long opsApplicationID;
	private String pinCode;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String addressLine5;
	private String addressType;
	private String businessDriver1;
	private String businessDriver2;
	private String businessDriver3;
	
	
	@OneToOne(fetch = FetchType.EAGER,
            cascade =  CascadeType.ALL,
            mappedBy = "partnerAddress")
	
	@JsonBackReference
    private PartnershipDetails partnerDetails;
	
	
	
	public OpsAddress() {
		super();
	}

	public OpsAddress(String pinCode, String addressLine1, String addressLine2, String addressLine3,
			String addressLine4, String addressLine5) {
		super();
		this.pinCode = pinCode;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.addressLine4 = addressLine4;
		this.addressLine5 = addressLine5;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	public String getAddressLine5() {
		return addressLine5;
	}

	public void setAddressLine5(String addressLine5) {
		this.addressLine5 = addressLine5;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public String getBusinessDriver1() {
		return businessDriver1;
	}

	public void setBusinessDriver1(String businessDriver1) {
		this.businessDriver1 = businessDriver1;
	}

	public String getBusinessDriver2() {
		return businessDriver2;
	}

	public void setBusinessDriver2(String businessDriver2) {
		this.businessDriver2 = businessDriver2;
	}

	public String getBusinessDriver3() {
		return businessDriver3;
	}

	public void setBusinessDriver3(String businessDriver3) {
		this.businessDriver3 = businessDriver3;
	}

	public long getOpsApplicationID() {
		return opsApplicationID;
	}

	public void setOpsApplicationID(long opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}

	public PartnershipDetails getPartnerDetails() {
		return partnerDetails;
	}

	public void setPartnerDetails(PartnershipDetails partnerDetails) {
		this.partnerDetails = partnerDetails;
	}
	
	

}
