import React, { Component, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Box from "@material-ui/core/Box";
import PartnerDetails from "./PartnerDetails";
import { SecurityContext } from "../Context/SecurityContext";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import FormLabel from "@material-ui/core/FormLabel";
import Address from "./Address";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput,
  MenuList
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "left",
    color: theme.palette.text.secondary
  }
}));

export default function PartnershipDetails() {
  const { guarantorDetails, setGuarDetails } = useContext(
    CreateSecurityRequestContext
  );

  const classes = useStyles();
  const [value, setValue] = React.useState("female");

  const [GuaratorType, setGuaratorType] = React.useState({
    type: ""
  });

  const partnershipAddress = { ...guarantorDetails };

  const handleGurtypeChange = event => {
    const name = event.target.name;
    setGuaratorType({
      type: event.target.value
    });
  };

  const handleFirmName = event => {
    console.log(event.target.id);
  };

  const onAddressChange = address => {
    partnershipAddress.partnershipDetails.partnerAddress = address;
    setGuarDetails(partnershipAddress);
  };

  const handleTextboxChange = event => {
    switch (event.target.id) {
      case "firmName":
        partnershipAddress.partnershipDetails.firmName = event.target.value;
        setGuarDetails(partnershipAddress);
        break;

      case "cinName":
        partnershipAddress.partnershipDetails.cin = event.target.value;
        setGuarDetails(partnershipAddress);
        break;

      case "tradingName":
        partnershipAddress.partnershipDetails.tradingName = event.target.value;
        setGuarDetails(partnershipAddress);
        break;

      default:
        break;
    }
  };

  return (
    <div className={classes.root}>
      <Paper className={classes.paper}>
        <Grid container>
          <Grid item xs={12} sm={12} xl={12}>
            <Typography variant="h6">Partnership Details</Typography>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl margin="normal" style={{ minWidth: 350 }}>
              <InputLabel htmlFor="name">Partnership / Firm Name </InputLabel>
              <Input
                id="firmName"
                value={partnershipAddress.partnershipDetails.firmName}
                autoComplete="off"
                type="text"
                onChange={handleTextboxChange}
                defaultValue=""
                startAdornment={
                  <InputAdornment position="start">
                    <AccountBalanceIcon />
                  </InputAdornment>
                }
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4} xl={4}>
            <FormControl margin="normal" style={{ minWidth: 350 }}>
              <InputLabel htmlFor="name">Trading Name </InputLabel>
              <Input
                id="tradingName"
                value={partnershipAddress.partnershipDetails.tradingName}
                autoComplete="off"
                type="text"
                defaultValue="RBS Bank"
                onChange={handleTextboxChange}
                startAdornment={
                  <InputAdornment position="start">
                    <TrendingUpIcon />
                  </InputAdornment>
                }
              />
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={3} xl={4}>
            <FormControl margin="normal" style={{ minWidth: 350 }}>
              <InputLabel htmlFor="name">CIN </InputLabel>
              <Input
                id="cinName"
                value={partnershipAddress.partnershipDetails.cin}
                autoComplete="off"
                type="text"
                defaultValue="RBS Bank"
                onChange={handleTextboxChange}
                startAdornment={
                  <InputAdornment position="start">
                    <TrendingUpIcon />
                  </InputAdornment>
                }
              />
            </FormControl>
          </Grid>

          <div>
            <br></br>
            <br></br>
            <br></br>
          </div>

          <Grid container item xs={12} spacing={2}>
            <Address
              context="SecurityContext"
              address={partnershipAddress.partnershipDetails.partnerAddress}
              onAddressChange={onAddressChange} // SENDING FUCTION AS PROPS .Assigning line 66 variable.
            />
          </Grid>

          <Grid container item xs={12} sm={12} xl={12}>
            <Typography variant="h6">Partner Details</Typography>
          </Grid>

          <Grid item xs={4}>
            <PartnerDetails />
          </Grid>
        </Grid>
      </Paper>
    </div>
  );
}
