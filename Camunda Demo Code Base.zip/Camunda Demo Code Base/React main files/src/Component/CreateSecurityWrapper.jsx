import React, { Component, useContext, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import CreateSecurity from "./CreateSecurity";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Box from "@material-ui/core/Box";
import PersonPinCircleIcon from "@material-ui/icons/PersonPinCircle";
import SearchIcon from "@material-ui/icons/Search";
import Container from "@material-ui/core/Container";
import SecurityContextProvider from "../Context/SecurityContext";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import FormLabel from "@material-ui/core/FormLabel";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput,
  MenuList,
  Icon
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%"
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "left",
    color: theme.palette.text.secondary
  },
  lineHeight: {
    lineHeight: "80px"
  },
  label: {
    textTransform: "capitalize"
  }
}));

export default function CreateSecurityWrapper() {
  // updating parent variables value

  const [WrapperData1, updateWrapper1] = React.useState({ name: "ssv" });

  const [guarantorDetails, setGuarDetails] = useState({
    guarantorResidence: "",
    signGuarantorResidence: "",
    guarantorType: "",
    partnershipDetails: {
      firmName: "",
      tradingName: "",
      cin: "",
      partnerAddress: {
        pinCode: "",
        addressLine1: "",
        addressLine2: "",
        addressLine3: "",
        addressLine4: "",
        addressLine5: ""
      }
    }
  });

  const [securityDetails, setSecurityDetails] = useState({
    anySuppourtingSecurity: "",
    numberOfSecurity: "",
    opsApplicationID: "",
    taskID: "",
    suppourtingSecurityDetails: [
      {
        securityType: "",
        securityStatus: "",
        securityForeName: "",
        securityIdNumber: ""
      }
    ]
  });

  const [additionalInformation, setAdditionalInformation] = useState({
    additionalInformationComments: "",
    estimatedCompletionDate: ""
  });

  const [customerInformation, setcustomerInformation] = useState({
    customerName: "",
    customerTradingName: "",
    customerCin: "",
    customerLegalEntityType: "",
    customerContactName: "",
    customerAddress: ""
  });

  const [L1Information, setL1Information] = useState({
    L1Comments: "",
    L1Approver: "",
    L1Action: ""
  });

  const [L2Information, setL2Information] = useState({
    L2Comments: "",
    L2Approver: "",
    L2Action: ""
  });

  const [L3Information, setL3Information] = useState({
    L3Comments: "",
    L3Approver: "",
    L3Action: ""
  });

  return (
    <div>
      <CreateSecurityRequestContext.Provider
        value={{
          guarantorDetails,
          setGuarDetails,
          securityDetails,
          setSecurityDetails,
          additionalInformation,
          setAdditionalInformation,
          customerInformation,
          setcustomerInformation,
          L1Information,
          setL1Information,
          L2Information,
          setL2Information,
          L3Information,
          setL3Information
        }}
      >
        <CreateSecurity />
      </CreateSecurityRequestContext.Provider>
    </div>
  );
}
