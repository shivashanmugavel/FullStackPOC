package com.ops_poc.restcontroller.dao.repository;

import org.springframework.data.repository.CrudRepository;

import com.ops_poc.restcontroller.dao.model.PartnershipDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;

public interface PartnershipRepository  extends CrudRepository<PartnershipDetails, Long> 
{
	
	PartnershipDetails findByOpsApplicationID(long opsID);

}
