package com.ops_poc.restcontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.ops_poc.dto.CreateSecurityPayLoad;
import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;
import com.ops_poc.restcontroller.dao.repository.CustomerInformation;
import com.ops_poc.restcontroller.dao.repository.SecurityRepository;

@RestController
@RequestMapping(value = "/ops/GenericService")
public class OpsGenericServiceController {
	
	@Autowired
	private CustomerInformation customerRepository;
	@Autowired
	private Gson gson;
	private Iterable<CustomerDetails> cusDetails;
	
	@Autowired
	private SecurityRepository secRepo;
	
	
	
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/GetCustomerDetailsByCin")
	@PostMapping(
	        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}
	)
    public String getCustomerDetails(@RequestBody CustomerDetails custDetails)
	{
		
		 
		 cusDetails = customerRepository.getCustomerInformation(custDetails.getCustomerCin());
		//return customerRepository.findById((long) 1234567890);
		 return gson.toJson(cusDetails);
	}

	@RequestMapping("/AddCustomerDetailsByCin")
    public String  addCustomerDetailsDetails()
	{
		
		CustomerDetails cd1 = new CustomerDetails(1, "Ganesha", "1234567890", "eg@gmail.com","094444946185", "India");
		CustomerDetails cd2 = new CustomerDetails(2, "Muruga", "1234567891", "eg@gmail.com","094444946185", "India");
		CustomerDetails cd3 = new CustomerDetails(3, "Ganesha", "1234567892", "eg@gmail.com","094444946185", "India");
		CustomerDetails cd4 = new CustomerDetails(4, "ABC cottons", "123", "eg@gmail.com","094444946185", "India");
		
		customerRepository.save(cd1);
		customerRepository.save(cd2);
		customerRepository.save(cd3);
		customerRepository.save(cd4);
		
		cusDetails = customerRepository.findAll();
		
		
		return   gson.toJson(cusDetails);
		//return customerRepository.findById((long) 1234567890);
		
	}
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/getApplicationId")
    public String  getApplicationID()
	{
		
		long applicationID = secRepo.getApplicationID();
		
		
		return   gson.toJson(applicationID);
	
		
	}
	
	

}
