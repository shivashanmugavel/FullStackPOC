package com.ops_poc.restcontroller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.camunda.bpm.engine.FilterService;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.authorization.Groups;
import org.camunda.bpm.engine.history.HistoricVariableInstance;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.runtime.VariableInstanceQuery;
import org.camunda.bpm.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.ops_poc.dto.OpsServiceResponse;
import com.ops_poc.restcontroller.dao.model.ApplicationDetaislForInbox;
import com.ops_poc.restcontroller.dao.model.CustomerDetails;
import com.ops_poc.restcontroller.dao.model.InboxDetails;
import com.ops_poc.restcontroller.dao.model.OpsUserInfo;
import com.ops_poc.restcontroller.dao.model.ProcessComments;
import com.ops_poc.restcontroller.dao.model.SecurityDetails;
import com.ops_poc.restcontroller.dao.repository.ProcessCommentsRepository;
import com.ops_poc.restcontroller.dao.repository.SecurityRepository;


@RestController
@RequestMapping(value = "/ops/TaskService")
public class OpsTaskController {
	
	
	@Autowired
	 private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private Gson gson;
	
	@Autowired
	private IdentityService identityService ;
	
	@Autowired
	private FilterService filterService;
	
	@Autowired
	private HistoryService historicService;
	
	
	@Autowired
	private ProcessCommentsRepository pcRepository;
	
	@Autowired
	private SecurityRepository secRepository;
	
	
	@RequestMapping("/getTeamFilter")
	 public  String getTeamFilter() {
		
		
		 
		identityService.createGroupQuery().groupMember("demo").list();
		
		List<Task> tasks = taskService.createTaskQuery()
				              .taskAssignee("demo").list(); 
		
		Set<String> procIds = new HashSet<String>(); 
		 String instanceIDCmmmaSep = tasks.stream()
				 .map( n -> n.getProcessInstanceId().toString())
                .collect(Collectors.joining(","));
		 
		 for (Task t : tasks) { 
	            // Add each element into the set 
			 procIds.add(t.getProcessInstanceId()); 
	        } 
		 
		
		 System.out.println("procids" + procIds );
		 
		List<ProcessInstance> processID=runtimeService.createProcessInstanceQuery().processInstanceIds(procIds).list();
		 
	
		 String jsonStr = gson.toJson(processID);
	        
	        
	        return jsonStr;
		 
	}
	
	
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/getMyTeamInbox")
	 public  String getMyTeamInbox( @RequestBody OpsUserInfo userInfo ) {
			  
		List<InboxDetails>  inboxDetails = new ArrayList<InboxDetails>();
		List<String> groupList=new ArrayList<String>();
		List<String> taskIDToFetch=new ArrayList<String>();
		List<SecurityDetails> securityDetails=new ArrayList<SecurityDetails>();
		
		System.out.println("user id"  + userInfo.getUserID());
		
		List<Group> myGroups = identityService.createGroupQuery().groupMember(userInfo.getUserID()).list();
		
		
       for ( int i =0 ; i< myGroups.size(); i++ )
        {
   	      groupList.add(myGroups.get(i).getName());
	    }
    
    System.out.println(groupList);

		
		//List<String> myInboxGroup = Arrays. asList("L1 Approver", "L2 Approver", "L3 Approver");
		/* List<Task> tasks = taskService.createTaskQuery()
				  .taskAssignee("demo").list(); */
		
		//identityService.createGroupQuery().groupMember("demo").list();
		 
		 List<Task> tasks = taskService.createTaskQuery()
				  .taskCandidateGroupIn(groupList).list(); 
		 
		
		 
		 //actually not required .. to be deleted after test 
		 //Set<String> taskids = new HashSet<String>(); 
		// String taskidsCommaSep = tasks.stream()
				// .map( n -> n.getId())
				// .collect(Collectors.joining(","));
		 
		 
		 for ( int j =0 ; j< tasks.size(); j++ )
	        {
			 taskIDToFetch.add(tasks.get(j).getId());
		    }
		 
		 securityDetails = secRepository.findBytaskIDIn(taskIDToFetch);
		 
		 for ( int j =0 ; j< securityDetails.size(); j++ )
		    { 
			    // Add each element into the set 
			 inboxDetails.add(j,new InboxDetails());
			 		
			 
			 inboxDetails.get(j).setAppInboxData(new ApplicationDetaislForInbox());
			 inboxDetails.get(j).getAppInboxData().setApplicationID(securityDetails.get(j).getOpsApplicationID());
			 inboxDetails.get(j).getAppInboxData().setCustomerName(securityDetails.get(j).getCustomerName());
			 inboxDetails.get(j).getAppInboxData().setCustomerContactPerson(securityDetails.get(j).getCustomerContactName());
			 inboxDetails.get(j).getAppInboxData().setCustomerPhoneNumber(securityDetails.get(j).getCustomerPhoneNumber());
			 inboxDetails.get(j).getAppInboxData().setNumberOfPartners(securityDetails.get(j).getNumberOfSecurity());
			 
			 String tt1= securityDetails.get(j).getTaskID();
			 
			Task taskDetails = tasks.stream()
					 .filter( rec -> rec.getId() ==  tt1)
					 .findFirst()
					 .get();  
			 
			inboxDetails.get(j).setTaskDetails(taskDetails);
			
			 
	        }
		 
		  
		 String myInboxTasks = gson.toJson(inboxDetails);
		 
		   
	     return myInboxTasks;
	        
	        
/*	        Set<String> procIds = new HashSet<String>(); 
			 String instanceIDCmmmaSep = tasks.stream()
					 .map( n -> n.getProcessInstanceId().toString())
	                 .collect(Collectors.joining(","));
			 
			 for (Task t : tasks) { 
		            // Add each element into the set 
				 procIds.add(t.getProcessInstanceId()); 
		        } 
			 
			 System.out.println("comma seperated value:  "+instanceIDCmmmaSep);

			 
			 working code for process variable
			 List<HistoricVariableInstance> variableQuery;
			variableQuery = historicService.createHistoricVariableInstanceQuery().processInstanceIdIn(instanceIDCmmmaSep).list();
	        */
		 
	} // end of getMyGroupTask method
	
	
	
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/claimTask")
	 public  String claimTask( @RequestBody OpsUserInfo userInfo ) {
		
		OpsServiceResponse osr = new OpsServiceResponse();
		
		
		taskService.claim(userInfo.getTaskID(), userInfo.getUserID());
		  
		  osr.setData("Task Claimed Sucessfully");
		  
		  String response = gson.toJson(osr);
		 
		  return response;
	        

		 
	}
	
	

	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/getMyInbox")
	 public  String getMyInbox( @RequestBody OpsUserInfo userInfo ) {
			  
		List<InboxDetails>  inboxDetails = new ArrayList<InboxDetails>();
		List<String> taskIDToFetch=new ArrayList<String>();
		List<SecurityDetails> securityDetails=new ArrayList<SecurityDetails>();
		 List<Task> tasks = taskService.createTaskQuery().taskAssignee(userInfo.getUserID()).list();
		 
		 System.out.println("task details  " +tasks);
		 
		 for ( int j =0 ; j< tasks.size(); j++ )
	        {
			 taskIDToFetch.add(tasks.get(j).getId());
		    }
		 
		 	 
		 
		 securityDetails = secRepository.findBytaskIDIn(taskIDToFetch);
		 
		 for ( int j =0 ; j< securityDetails.size(); j++ )
		    { 
			    // Add each element into the set 
			 inboxDetails.add(j,new InboxDetails());
			 		
			 
			 inboxDetails.get(j).setAppInboxData(new ApplicationDetaislForInbox());
			 inboxDetails.get(j).getAppInboxData().setApplicationID(securityDetails.get(j).getOpsApplicationID());
			 inboxDetails.get(j).getAppInboxData().setCustomerName(securityDetails.get(j).getCustomerName());
			 inboxDetails.get(j).getAppInboxData().setCustomerContactPerson(securityDetails.get(j).getCustomerContactName());
			 inboxDetails.get(j).getAppInboxData().setCustomerPhoneNumber(securityDetails.get(j).getCustomerPhoneNumber());
			 inboxDetails.get(j).getAppInboxData().setNumberOfPartners(securityDetails.get(j).getNumberOfSecurity());
			 String tt1= securityDetails.get(j).getTaskID();
			 
			Task taskDetails = tasks.stream()
					 .filter( rec -> rec.getId() ==  tt1)
					 .findFirst()
					 .get();  
			 
			inboxDetails.get(j).setTaskDetails(taskDetails);
			
			 
	        }
		 
		 
		 
		 /* backuop of inbox
		  * for ( int j =0 ; j< tasks.size(); j++ )
		    { 
	            // Add each element into the set 
			 inboxDetails.add(j,new InboxDetails());
			 		
			 inboxDetails.get(j).setTaskDetails(tasks.get(j));
			 
	        }*/
		 
		 
		 
		 String myInboxTasks = gson.toJson(inboxDetails);
		 
		   
	     return myInboxTasks;
	        

		 
	} 
	

	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/unClaim")
	 public  String unClaimTask( @RequestBody OpsUserInfo userInfo ) {
		
		OpsServiceResponse osr = new OpsServiceResponse();
				 
		  taskService.claim(userInfo.getTaskID(), null);
		  
		  osr.setData("Task Un-Claimed Sucessfully");
		 
		  String response = gson.toJson(osr);
			 
		  return response;
		  
		  
	  		 
	}
	
	@CrossOrigin(origins = "http://localhost:3000")
	@RequestMapping("/completeTask")
	 public  String completeTask( @RequestBody OpsUserInfo userInfo ) {
		
		OpsServiceResponse osr = new OpsServiceResponse();
ProcessComments pc = new ProcessComments();
		
        LocalDateTime commentsTiming = LocalDateTime.now(); 
       

		pc.setUserName(userInfo.getUserName());
		pc.setOpsApplicationID(userInfo.getOpsApplicationID());
		pc.setComments(userInfo.getComments());
		pc.setCommentsDate( commentsTiming.toString());
		pc.setUserAction(userInfo.getUserDecision());
		pc.setProcessStage(userInfo.getProcessStage());
		
		pcRepository.save(pc);
		
		
		
           Map<String, Object> taskVariables = new HashMap<String, Object>();
		
           taskVariables.put("userAction",userInfo.getUserDecision());
           
           System.out.println("task details id  " +userInfo.getTaskID()+" user action"  + userInfo.getUserDecision() );
			  
				 
		  taskService.complete(userInfo.getTaskID(), taskVariables);
		  
		  osr.setData("Task Completed Sucessfully");
		  
		  String response = gson.toJson(osr);
			 
		  return response;
		 
		  
	  		 
	}
	
	
}
