import React, { Component, useContext } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import AccountBalanceIcon from "@material-ui/icons/AccountBalance";
import InputAdornment from "@material-ui/core/InputAdornment";
import TrendingUpIcon from "@material-ui/icons/TrendingUp";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Box from "@material-ui/core/Box";
import AddSupportingSecurity from "./AddSupportingSecurity";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";

import FormLabel from "@material-ui/core/FormLabel";
import Address from "./Address";

import {
  FormControl,
  InputLabel,
  Input,
  Button,
  TextField,
  MenuItem,
  Select,
  Switch,
  FormGroup,
  OutlinedInput,
  MenuList
} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    "marigin-top": "100px"
  },
  paper: {
    padding: theme.spacing(3),
    textAlign: "left",
    color: theme.palette.text.secondary
  }
}));

export default function SecurityDetails() {
  const classes = useStyles();
  const [value, setValue] = React.useState("female");
  const { securityDetails, setSecurityDetails } = useContext(
    CreateSecurityRequestContext
  );

  const securityDetailsLocal = { ...securityDetails };

  const handleChangeSupportingSecurity = event => {
    console.log("SEcDetaisl test " + event.target.value);
    securityDetailsLocal.anySuppourtingSecurity = event.target.value;
    setSecurityDetails(securityDetailsLocal);
  };

  const handleChangeNUmberOfSecurity = event => {
    securityDetailsLocal.numberOfSecurity = event.target.value;
    setSecurityDetails(securityDetailsLocal);
  };

  return (
    <div className={classes.root}>
      <Paper className={classes.paper}>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={12} xl={12}>
            <Typography variant="h6">Security Details</Typography>
          </Grid>

          <Grid item xs={12} sm={12} xl={12}>
            <Paper className={classes.paper}>
              <div style={{ width: "100%" }}>
                <FormControl component="fieldset">
                  <FormLabel component="legend">
                    Is there any supporting security ?
                  </FormLabel>
                  <RadioGroup
                    row
                    aria-label="gender"
                    name="supportingSecurity"
                    onChange={handleChangeSupportingSecurity}
                    value={securityDetailsLocal.anySuppourtingSecurity}
                  >
                    <FormControlLabel
                      value="Yes"
                      control={<Radio />}
                      label="Yes"
                    />
                    <FormControlLabel
                      value="No"
                      control={<Radio />}
                      label="No"
                    />
                  </RadioGroup>
                </FormControl>
              </div>
            </Paper>
          </Grid>

          <Grid item xl={12}>
            <Paper className={classes.paper}>
              <FormControl
                className={classes.formControl}
                style={{ minWidth: 500 }}
              >
                <InputLabel id="demo-simple-select-label">
                  How many items of security are there ?
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={GuaratorType.type}
                  native
                  onChange={handleChangeNUmberOfSecurity}
                  //value={securityDetailsLocal.numberOfSecurity}
                  defaultValue={securityDetailsLocal.numberOfSecurity}
                >
                  <option value={"Please Select"}>Please Select</option>
                  <option value={"1"}>1</option>
                  <option value={"2"}>2</option>
                  <option value={"3"}>3</option>
                  <option value={"4"}>4</option>
                </Select>
              </FormControl>
            </Paper>
          </Grid>

          <Grid container item xs={12} sm={12} xl={12}>
            <Typography variant="h6">Supporting Security Details</Typography>
          </Grid>

          <Grid item xs={4}>
            <AddSupportingSecurity />
          </Grid>
        </Grid>
      </Paper>
    </div>
  );
}
