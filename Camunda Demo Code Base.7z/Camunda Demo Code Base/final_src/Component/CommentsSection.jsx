import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import Radio from "@material-ui/core/Radio";
import Button from "@material-ui/core/Button";
import About from "./About";
import { MemoryRouter as Router } from "react-router";
import { Link, NavLink, withRouter } from "react-router-dom";
import { Link as RouterLink } from "react-router-dom";

const useStyles = makeStyles({
  table: {
    minWidth: 300
  }
});

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

export default function CommentsSection(props) {
  const classes = useStyles();
  const [selectedValue, setSelectedValue] = React.useState("");

  const handleChange = event => {
    setSelectedValue(event.target.value);
    console.log(props);
  };

  console.log("comments props" + JSON.stringify(props));

  const commentsFound = props.processComments.processComments.length;

  return commentsFound > 0 || commentsFound == 0 ? (
    <div>
      <TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell align="center">
                <b>Process Team and Stage</b>
              </TableCell>
              <TableCell align="center">
                <b>User Name</b>
              </TableCell>
              <TableCell align="center">
                <b>Comments </b>
              </TableCell>
              <TableCell align="center">
                <b>Comments Date</b>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {props.processComments.processComments.map(row => (
              <TableRow key={row.id}>
                <TableCell align="center">{row.processStage}</TableCell>
                <TableCell align="center">{row.userName}</TableCell>
                <TableCell align="center">{row.comments}</TableCell>
                <TableCell align="center">{row.commentsDate}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  ) : (
    <div align="center">No Records found</div>
  );
}
