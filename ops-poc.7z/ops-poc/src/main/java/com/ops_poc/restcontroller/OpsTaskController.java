package com.ops_poc.restcontroller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.camunda.bpm.engine.FilterService;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.authorization.Groups;
import org.camunda.bpm.engine.history.HistoricVariableInstance;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.runtime.VariableInstanceQuery;
import org.camunda.bpm.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;


@RestController
@RequestMapping(value = "/ops/TaskService")
public class OpsTaskController {
	
	
	@Autowired
	 private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private Gson gson;
	
	@Autowired
	private IdentityService identityService ;
	
	@Autowired
	private FilterService filterService;
	
	@Autowired
	private HistoryService historicService;
	
	
	@RequestMapping("/getTeamFilter")
	 public  String getTeamFilter() {
		
		 
		identityService.createGroupQuery().groupMember("demo").list();
		
		List<Task> tasks = taskService.createTaskQuery()
				              .taskAssignee("demo").list(); 
		
		Set<String> procIds = new HashSet<String>(); 
		 String instanceIDCmmmaSep = tasks.stream()
				 .map( n -> n.getProcessInstanceId().toString())
                .collect(Collectors.joining(","));
		 
		 for (Task t : tasks) { 
	            // Add each element into the set 
			 procIds.add(t.getProcessInstanceId()); 
	        } 
		 
		
		 System.out.println("procids" + procIds );
		 
		List<ProcessInstance> processID=runtimeService.createProcessInstanceQuery().processInstanceIds(procIds).list();
		 
	
		 String jsonStr = gson.toJson(processID);
	        
	        
	        return jsonStr;
		 
	}
	
	
	
	
	@RequestMapping("/getMyInbox")
	 public  String getMyGroupTask() {
			  
		
		ArrayList<String> groupList=new ArrayList<String>();
		
		List<Group> myGroups = identityService.createGroupQuery().groupMember("demo").list();
		
		
       for ( int i =0 ; i< myGroups.size(); i++ )
        {
   	      groupList.add(myGroups.get(i).getName());
	    }
    
    System.out.println(groupList);

		
		//List<String> myInboxGroup = Arrays. asList("L1 Approver", "L2 Approver", "L3 Approver");
		/* List<Task> tasks = taskService.createTaskQuery()
				  .taskAssignee("demo").list(); */
		
		identityService.createGroupQuery().groupMember("demo").list();
		 
		 List<Task> tasks = taskService.createTaskQuery()
				  .taskCandidateGroupIn(groupList).list();
		  
		 
		 
		 String myInboxTasks = gson.toJson(tasks);
		 
		   
	     return myInboxTasks;
	        
	        
/*	        Set<String> procIds = new HashSet<String>(); 
			 String instanceIDCmmmaSep = tasks.stream()
					 .map( n -> n.getProcessInstanceId().toString())
	                 .collect(Collectors.joining(","));
			 
			 for (Task t : tasks) { 
		            // Add each element into the set 
				 procIds.add(t.getProcessInstanceId()); 
		        } 
			 
			 System.out.println("comma seperated value:  "+instanceIDCmmmaSep);

			 
			 working code for process variable
			 List<HistoricVariableInstance> variableQuery;
			variableQuery = historicService.createHistoricVariableInstanceQuery().processInstanceIdIn(instanceIDCmmmaSep).list();
	        */
		 
	} // end of getMyGroupTask method


	
	
	
}
