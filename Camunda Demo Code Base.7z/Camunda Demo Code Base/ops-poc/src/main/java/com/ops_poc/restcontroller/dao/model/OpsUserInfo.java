package com.ops_poc.restcontroller.dao.model;

public class OpsUserInfo {
	
	private String userName;
	private String userID;
	private String userEmailID;
	private String taskID;
	private String userDecision;
	private String comments;
	private String commentsDate;
	private Long opsApplicationID;
	private String processStage;
	
	
	public OpsUserInfo() {


		// TODO Auto-generated constructor stub
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserID() {
		return userID;
	}


	public void setUserID(String userID) {
		this.userID = userID;
	}


	public String getUserEmailID() {
		return userEmailID;
	}


	public void setUserEmailID(String userEmailID) {
		this.userEmailID = userEmailID;
	}


	public String getTaskID() {
		return taskID;
	}


	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}


	public String getUserDecision() {
		return userDecision;
	}


	public void setUserDecision(String userDecesion) {
		this.userDecision = userDecesion;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getCommentsDate() {
		return commentsDate;
	}


	public void setCommentsDate(String commentsDate) {
		this.commentsDate = commentsDate;
	}


	public Long getOpsApplicationID() {
		return opsApplicationID;
	}


	public void setOpsApplicationID(Long opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}


	public String getProcessStage() {
		return processStage;
	}


	public void setProcessStage(String processStage) {
		this.processStage = processStage;
	}
	
	
	

}
