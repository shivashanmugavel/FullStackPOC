package com.ops_poc.restcontroller;

import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.impl.pvm.delegate.TaskListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


import com.ops_poc.restcontroller.dao.repository.SecurityRepository;

@Component
public class TaskCreationListner implements org.camunda.bpm.engine.delegate.TaskListener{

	//@Autowired
	//@Qualifier("OpsHelper")
	//private SecurityRepository secRepository ;
	

	@Autowired
	private  SecurityRepository secRepository;
	
	@Autowired
	private OpsHealperClass ohc;
	
	
	
	
	Map<String, Object> taskVariables=new HashMap<String,Object>();    
	@Override
	public void notify(DelegateTask arg0) {
		
	taskVariables = arg0.getVariables();
			
	String taskID = arg0.getId();
	 
	Long opsApplicationID = Long.parseLong(taskVariables.get("opsID").toString()) ;
	
	
	  taskUpdateRepo(opsApplicationID,taskID);
	
	  
	
	}
	
	
	
	//update the task id with corresponding ops id
	public void taskUpdateRepo(long opsApplicationID,String taskID )
	{
		
			
		secRepository.updateTaskID(opsApplicationID,taskID);
	}

}
