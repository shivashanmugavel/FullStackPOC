import React, { Component, useContext, useEffect } from "react";
import { useHistory } from "react-router-dom";
import Contact from "./Contact";
import { BrowserRouter, Route } from "react-router-dom";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import PhoneIcon from "@material-ui/icons/Phone";
//import FavoriteIcon from "@material-ui/icons/Favorite";
import PersonPinIcon from "@material-ui/icons/PersonPin";
import HelpIcon from "@material-ui/icons/Help";
import ShoppingBasket from "@material-ui/icons/ShoppingBasket";
import ThumbDown from "@material-ui/icons/ThumbDown";
import ThumbUp from "@material-ui/icons/ThumbUp";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import AccountBalanceOutlinedIcon from "@material-ui/icons/AccountBalanceOutlined";
import CustomerDetails from "./CustomerDetails";
import GuarantorDetails from "./GuarantorDetails";
import SecurityDetails from "./SecurityDetails";
import AdditionalInformation from "./AdditionalInformation";
import L1Section from "./L1Section";
import L2Section from "./L2Section";
import L3Section from "./L3Section";
import SecurityContextProvider from "../Context/SecurityContext";
import axios from "axios";
import { CreateSecurityRequestContext } from "../Context/CreateSecurityRequestContext";
import { Redirect, withRouter } from "react-router-dom";
import PersonIcon from "@material-ui/icons/Person";

import Button from "@material-ui/core/Button";
import Icon from "@material-ui/core/Icon";
import SendIcon from "@material-ui/icons/Send";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { SecurityContext } from "../Context/SecurityContext";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component="div"
      role="tabpanel"
      hidden={value !== index}
      id={`scrollable-force-tabpanel-${index}`}
      aria-labelledby={`scrollable-force-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </Typography>
  );
}

function TabSelections(formID) {}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired
};

function a11yProps(index) {
  return {
    id: `scrollable-force-tab-${index}`,
    "aria-controls": `scrollable-force-tabpanel-${index}`
  };
}

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
    width: "100%",
    backgroundColor: theme.palette.background.paper
  }
}));
const CreateSecurity = props => {
  const CreateSecurityPayload = {
    createSecurityRequest: {
      customerDetails: {},
      guarantorDetails: {},
      securityDetails: {},
      additionalInformation: {}
    }
  };
  const classes = useStyles();

  //const formNotification = props.state.fromNotifications;

  const {
    guarantorDetails,
    setGuarDetails,
    securityDetails,
    setSecurityDetails,
    additionalInformation,
    setAdditionalInformation,
    L1Information,
    setL1Information,
    L2Information,
    setL2Information,
    L3Information,
    setL3Information
  } = useContext(CreateSecurityRequestContext);

  const [dioOpen, setDioOpen] = React.useState(false);

  const handleDialogClickOpen = () => {
    setDioOpen(true);
  };

  const handleDiologClose = formid => {
    setDioOpen(false);
    switch (formid) {
      case "Level 1 Approval":
      case "Level 2 Approval":
      case "Level 3 Approval": {
        history.push("/MyInbox");
        break;
      }

      case "CreateSecurity":
        history.push("/Create Security");
        break;
    }
  };

  const [value, setValue] = React.useState(0);
  const [applicationID, setApplicationID] = React.useState(0);

  const userDetailsTask = {
    userName: "",
    userID: "demo",
    userEmailID: "",
    taskID: "",
    userDecision: ""
  };

  const [responseCheck, setRespnseCheck] = React.useState({
    ...securityDetails
  });

  const formState = { ...props };

  let fromID = formState.location.state.formID;

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const secDetails = { ...securityDetails };

  console.log("formnotification " + fromID);

  const history = useHistory();

  /*  const btn_handleCreateSecurity = () => {
    CreateSecurityPayload.GuarantorDetails = guarantorDetails;
    console.log(CreateSecurityPayload);
    //const url = "https://jsonplaceholder.typicode.com/users";
    const url = "http://localhost:8080/ops/CreateSecurity";
    const response = axios.post(url, CreateSecurityPayload).then(response => {
      //setSecDetails({ securityDetails: response.data, toDisplay: "" });
      console.log(response);
    });
  }; */

  const btn_handleCreateSecurity = async () => {
    CreateSecurityPayload.createSecurityRequest.guarantorDetails = guarantorDetails;
    CreateSecurityPayload.createSecurityRequest.securityDetails = securityDetails;
    CreateSecurityPayload.createSecurityRequest.additionalInformation = additionalInformation;
    console.log(CreateSecurityPayload);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(CreateSecurityPayload)
    };
    //const url = "https://jsonplaceholder.typicode.com/users";
    const url = "http://localhost:8084/ops/CreateSecurity";
    const response = await fetch(url, requestOptions)
      .then(res => res.json())
      .then(data => {
        console.log(data);
      })
      .catch(err => {
        console.log(err);
      });

    await handleDialogClickOpen(fromID);

    //history.push("/Create Security");
  };

  const btn_handleSubmitProcess = async () => {
    const urlSubmitTask = "http://localhost:8084/ops/TaskService/completeTask";

    userDetailsTask.taskID = formState.location.state.taskID;
    if (fromID == "Level 1 Approval") {
      userDetailsTask.userDecision = L1Information.L1Action;
    }

    if (fromID == "Level 2 Approval") {
      userDetailsTask.userDecision = L1Information.L2Action;
    }

    if (fromID == "Level 3 Approval") {
      userDetailsTask.userDecision = L1Information.L3Action;
    }

    const requestOptionsSubmit = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(userDetailsTask)
    };
    console.log("request" + userDetailsTask);
    const submitTaskResponse = await fetch(urlSubmitTask, requestOptionsSubmit)
      .then(res => res.json())
      .then(data => {})
      .catch(err => {
        console.log(err);
      });

    await handleDialogClickOpen(fromID);
  };

  useEffect(() => {
    if (fromID == "CreateSecurity") {
      const urlAppid =
        "http://localhost:8084/ops/GenericService/getApplicationId";
      const getApplicationID = fetch(urlAppid)
        .then(res => res.json())
        .then(data => {
          console.log("appid:" + data);
          const result = data;
          setApplicationID(result);
          secDetails.opsApplicationID = result;
          setSecurityDetails(secDetails);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }, []);

  useEffect(() => {
    if (fromID != "CreateSecurity") {
      CreateSecurityPayload.createSecurityRequest.securityDetails.taskID =
        formState.location.state.taskID;

      console.log(
        "sec details request form id :" +
          CreateSecurityPayload.createSecurityRequest.securityDetails.taskID
      );

      console.log(
        "sec details request " + JSON.stringify(CreateSecurityPayload)
      );

      const requestOptions = {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(CreateSecurityPayload)
      };

      const urlSecDetails = "http://localhost:8084/ops/GetSecurityDetails";
      const getApplicationID = fetch(urlSecDetails, requestOptions)
        .then(res => res.json())
        .then(data => {
          secDetails.opsApplicationID = data.securityDetails.opsApplicationID;
          setApplicationID(secDetails.opsApplicationID);

          setAdditionalInformation({
            additionalInformationComments:
              data.securityDetails.additionalInformationComments,
            estimatedCompletionDate:
              data.securityDetails.estimatedCompletionDate
          });

          setGuarDetails(data.guarantorDetails);

          setSecurityDetails({
            anySuppourtingSecurity: data.securityDetails.anySuppourtingSecurity,
            numberOfSecurity: data.securityDetails.numberOfSecurity,
            opsApplicationID: "",
            taskID: data.securityDetails.taskID,
            suppourtingSecurityDetails: [
              {
                securityType: "",
                securityStatus: "",
                securityForeName: "",
                securityIdNumber: ""
              }
            ]
          });
          console.log("sec details inner :" + data);
        })
        .catch(err => {
          console.log(err);
        });
    }
  }, []);

  return (
    <div className={classes.root}>
      <div
        style={{
          float: "right",
          marginRight: "20px"
        }}
      >
        Application ID : {applicationID}
      </div>

      <div>
        <Dialog
          open={dioOpen}
          onClose={handleDiologClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">
            {fromID == "CreateSecurity"
              ? "Security Created Sucessfully"
              : "Task Completed Sucessfully"}
          </DialogTitle>
          <DialogContent>
            {fromID == "Level 1 Approval" ||
            fromID == "Level 2 Approval" ||
            fromID == "Level 3 Approval" ? (
              <DialogContentText id="alert-dialog-description">
                Task Completed Sucessfully
              </DialogContentText>
            ) : null}

            {fromID == "CreateSecurity" ? (
              <DialogContentText id="alert-dialog-description">
                Application ID : {applicationID}
              </DialogContentText>
            ) : null}
          </DialogContent>
          <DialogActions>
            <Button onClick={handleDiologClose} color="primary" autoFocus>
              Ok
            </Button>
          </DialogActions>
        </Dialog>
      </div>
      <AppBar position="static">
        <Tabs
          value={value}
          onChange={handleChange}
          variant="scrollable"
          scrollButtons="on"
          indicatorColor="secondary"
          //textColor="primary"
          aria-label="scrollable force tabs example"
        >
          <Tab
            label="Customer Details"
            icon={<PhoneIcon />}
            {...a11yProps(0)}
            wrapped
          />
          <Tab
            label="Guarantor Details"
            icon={<AccountBalanceOutlinedIcon />}
            {...a11yProps(1)}
          />
          <Tab
            label="Security Details"
            icon={<PersonPinIcon />}
            {...a11yProps(2)}
          />
          <Tab
            label="Additional Information"
            icon={<HelpIcon />}
            {...a11yProps(3)}
          />
          {fromID == "Level 1 Approval" ||
          fromID == "Level 2 Approval" ||
          fromID == "Level 3 Approval" ? (
            <Tab label="L1 " icon={<PersonIcon />} {...a11yProps(4)} />
          ) : null}

          {fromID == "Level 3 Approval" || fromID == "Level 2 Approval" ? (
            <Tab label="L2 " icon={<PersonIcon />} {...a11yProps(5)} />
          ) : null}

          {fromID == "Level 3 Approval" ? (
            <Tab label="L3 " icon={<PersonIcon />} {...a11yProps(6)} />
          ) : null}

          {/* <Tab label="Rate" icon={<ShoppingBasket />} {...a11yProps(4)} />
          <Tab label="Item Six" icon={<ThumbDown />} {...a11yProps(5)} />
          <Tab label="Item Seven" icon={<ThumbUp />} {...a11yProps(6)} /> */}
        </Tabs>
      </AppBar>
      <TabPanel value={value} index={0}>
        <SecurityContextProvider>
          <CustomerDetails />
        </SecurityContextProvider>
      </TabPanel>
      <TabPanel value={value} index={1}>
        <SecurityContextProvider>
          <GuarantorDetails />
        </SecurityContextProvider>
      </TabPanel>
      <TabPanel value={value} index={2}>
        <SecurityDetails />
      </TabPanel>
      <TabPanel value={value} index={3}>
        <AdditionalInformation />
      </TabPanel>
      <TabPanel value={value} index={4}>
        <L1Section />
      </TabPanel>
      <TabPanel value={value} index={5}>
        <L2Section />
      </TabPanel>
      <TabPanel value={value} index={6}>
        <L3Section />
      </TabPanel>
      <div
        style={{
          float: "right",
          marginRight: "20px",
          marginBottom: "30px"
        }}
      >
        {fromID == "CreateSecurity" ? (
          <Button
            variant="contained"
            size="medium"
            color="primary"
            style={{ width: "200px", backgroundColor: "green" }}
            className={classes.button}
            endIcon={<SendIcon />}
            onClick={btn_handleCreateSecurity}
          >
            Create Sucurity
          </Button>
        ) : null}

        {fromID == "Level 1 Approval" ||
        fromID == "Level 2 Approval" ||
        fromID == "Level 3 Approval" ? (
          <Button
            variant="contained"
            size="medium"
            color="primary"
            style={{
              width: "150px",
              backgroundColor: "green",
              marginLeft: "20px"
            }}
            className={classes.button}
            endIcon={<SendIcon />}
            onClick={btn_handleSubmitProcess}
          >
            Submit
          </Button>
        ) : null}
      </div>
    </div>
  );
};

export default withRouter(CreateSecurity);
