package com.ops_poc.restcontroller.dao.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonManagedReference;


@Entity
public class PartnershipDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	 private long id;
	 private long opsApplicationID;
	 private String firmName;
	 private String tradingName;
	 private String cin;
	 
	   @OneToOne(fetch = FetchType.EAGER ,cascade =  CascadeType.ALL)
	    @JoinColumn(name = "OPS_ADDRESS_ID")
		
		@JsonManagedReference
	   	 private OpsAddress partnerAddress;
	 
	public PartnershipDetails() {
		super();
	}

	public String getFirmName() {
		return firmName;
	}

	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}

	public String getTradingName() {
		return tradingName;
	}

	public void setTradingName(String tradingName) {
		this.tradingName = tradingName;
	}

	public String getCIN() {
		return cin;
	}

	public void setCIN(String cIN) {
		cin = cIN;
	}

	public OpsAddress getPartnerAddress() {
		return partnerAddress;
	}

	public void setPartnerAddress(OpsAddress partnerAddress) {
		this.partnerAddress = partnerAddress;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getOpsApplicationID() {
		return opsApplicationID;
	}

	public void setOpsApplicationID(long opsApplicationID) {
		this.opsApplicationID = opsApplicationID;
	}
	
	
	 
	 
	 
	 
}
